﻿// JScript 檔


/* 變更 format 為 yyyy-MM-dd */
$.fn.datebox.defaults.formatter = function(date){
	var y = date.getFullYear();
	var m = date.getMonth()+1;
	var d = date.getDate();
	//return m+'/'+d+'/'+y;
	return y+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d);
}
$.fn.datebox.defaults.parser = function(s){
//	if (!isNaN(t)){
//		return new Date(t);
//	} else {
//		return new Date();
//	}
    if (!s) return new Date();
    var ss = (s.split('-'));
    var y = parseInt(ss[0],10);
    var m = parseInt(ss[1],10);
    var d = parseInt(ss[2],10);
    if (!isNaN(y) && !isNaN(m) && !isNaN(d)){
        return new Date(y,m-1,d);
    } else {
        return new Date();
    }
    	var t = Date.parse(s);
}


/*
*/
$.extend($.fn.datagrid.defaults.editors, {   
    textarea: {
        init: function(container, options){
            var input = $('<textarea class="datagrid-editable-input" rows='+options.rows+'></textarea>').appendTo(container);
            return input;
        },
        getValue: function(target){
            return $(target).val();
        },
        setValue: function(target, value){
            $(target).val(value);
        },
        resize: function(target, width){
            var input = $(target);
            if ($.boxModel == true){
                input.width(width - (input.outerWidth() - input.width()));
            } else {
                input.width(width);
            }
        }
    }
//    ,
//    // Try override the 'combobox' editor to support multiple selecting feature.
//	combobox: {
//		init: function(container, options){
//			var combo = $('<input type="text">').appendTo(container);
//			combo.combobox(options || {});
//			return combo;
//		},
//		destroy: function(target){
//			$(target).combobox('destroy');
//		},
//		getValue: function(target){
//			var opts = $(target).combobox('options');
//			if (opts.multiple){
//				return $(target).combobox('getValues').join(opts.separator);
//			} else {
//				return $(target).combobox('getValue');
//			}
//		},
//		setValue: function(target, value){
//			var opts = $(target).combobox('options');
//			if (opts.multiple){
//				if (value == ''){
//					$(target).combobox('clear');
//				} else {
//					$(target).combobox('setValues', value.split(opts.separator));
//				}
//			} else {
//				$(target).combobox('setValue', value);
//			}
//		},
//		resize: function(target, width){
//			$(target).combobox('resize', width)
//		}
//	}
}); 


/*
verify : ex: <input type="text" id="rate" name="rate" required="true" class="easyui-validatebox" validType="rateCheck[0,1000]" maxlength="6" />
*/
$.extend($.fn.validatebox.defaults.rules, {
				CHS: {
					validator: function (value, param) {
						return /^[\u0391-\uFFE5]+$/.test(value);
					},
					message: 'Please enter Chinese characters'
				},
				english : {// Test of English
			        validator : function(value) {
			            return /^[A-Za-z]+$/i.test(value);
			        },
			        message : 'Please enter English'
			    },
			    ip : {// Verify that the IP address
			        validator : function(value) {
			            return /\d+\.\d+\.\d+\.\d+/.test(value);
			        },
			        message : 'The IP address is not in the correct format'
			    },
				ZIP: {
					validator: function (value, param) {
						return /^[0-9]\d{5}$/.test(value);
					},
					message: 'Postal code does not exist'
				},
				QQ: {
					validator: function (value, param) {
						return /^[1-9]\d{4,10}$/.test(value);
					},
					message: 'The QQ number is not correct'
				},
				mobile: {
					validator: function (value, param) {
						return /^(?:13\d|15\d|18\d)-?\d{5}(\d{3}|\*{3})$/.test(value);
					},
					message: 'Mobile phone number is not correct'
				},
				tel:{
					validator:function(value,param){
						return /^(\d{3}-|\d{4}-)?(\d{8}|\d{7})?(-\d{1,6})?$/.test(value);
					},
					message:'The phone number is not correct'
				},
				mobileAndTel: {
					validator: function (value, param) {
						return /(^([0\+]\d{2,3})\d{3,4}\-\d{3,8}$)|(^([0\+]\d{2,3})\d{3,4}\d{3,8}$)|(^([0\+]\d{2,3}){0,1}13\d{9}$)|(^\d{3,4}\d{3,8}$)|(^\d{3,4}\-\d{3,8}$)/.test(value);
					},
					message: 'Please input correct phone number'
				},
				number: {
					validator: function (value, param) {
						//return /^[0-9]+?[0-9]*$/.test(value);
						return $.isNumeric(value)
					},
					message: 'Please enter a number'
				},
				money:{
					validator: function (value, param) {
					 	return (/^(([1-9]\d*)|\d)(\.\d{1,2})?$/).test(value);
					 },
					 message:'Please enter the correct amount'

				},
				mone:{
					validator: function (value, param) {
					 	return (/^(([1-9]\d*)|\d)(\.\d{1,2})?$/).test(value);
					 },
					 message:'Please enter an integer or decimal'

				},
				integer:{
					validator:function(value,param){
						return /^[+]?[1-9]\d*$/.test(value);
					},
					message: 'Please enter a minimum of 1 integer'
				},
				integ:{
					validator:function(value,param){
						return /^[+]?[0-9]\d*$/.test(value);
					},
					message: 'Please enter an integer'
				},
				range:{
					validator:function(value,param){
						if(/^[1-9]\d*$/.test(value)){
							return value >= param[0] && value <= param[1]
						}else{
							return false;
						}
					},
					message:'The number of input in the {0} to {1}'
				},
				minLength:{
					validator:function(value,param){
						return value.length >=param[0]
					},
					message:'Enter at least {0} words'
				},
				maxLength:{
					validator:function(value,param){
						return value.length<=param[0]
					},
					message:'Most {0} words'
				},
				//Select is the selection box verification
				selectValid:{
					validator:function(value,param){
						if(value == param[0]){
							return false;
						}else{
							return true ;
						}
					},
					message:'Please select'
				},
				idCode:{
					validator:function(value,param){
						return /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(value);
					},
					message: 'Please enter a valid identity card number'
				},
				loginName: {
					validator: function (value, param) {
						return /^[\u0391-\uFFE5\w]+$/.test(value);
					},
					message: 'The logon name only allows Chinese characters, letters, numbers and underscores English. '
				},
				equalTo: {
					validator: function (value, param) {
						return value == $(param[0]).val();
					},
					message: 'Two input character is not one to'
				},
				englishOrNum : {// English and digital input only
			        validator : function(value) {
			            return /^[a-zA-Z0-9_ ]{1,}$/.test(value);
			        },
			        message : 'Please enter English, digital, underlined or spaces'
			    },
			    xiaoshu:{ 
		            validator : function(value){ 
		            return /^(([1-9]+)|([0-9]+\.[0-9]{1,2}))$/.test(value);
	    	        }, 
    		        message : 'Up to two decimal places！'    
		    	},
		        ddPrice:{
				    validator:function(value,param){
					    if(/^[1-9]\d*$/.test(value)){
						    return value >= param[0] && value <= param[1];
					    }else{
						    return false;
					    }
				    },
				    message:'Please enter a positive integer between 1 to 100'
			    },
			    jretailUpperLimit:{
				    validator:function(value,param){
					    if(/^[0-9]+([.]{1}[0-9]{1,2})?$/.test(value)){
						    return parseFloat(value) > parseFloat(param[0]) && parseFloat(value) <= parseFloat(param[1]);
					    }else{
						    return false;
					    }
				    },
				    message:'Please enter between 0 to 100 up to two decimal digits'
			    },
			    rateCheck:{
				    validator:function(value,param){
					    if(/^[0-9]+([.]{1}[0-9]{1,2})?$/.test(value)){
						    return parseFloat(value) > parseFloat(param[0]) && parseFloat(value) <= parseFloat(param[1]);
					    }else{
						    return false;
					    }
				    },
				    message:'Please enter between 0 to 1000 up to two decimal digits'
			    },
	            checked: {  
		            validator: function(value, param){  
			            var input = $(param[0]);
			            input.unbind('.cc').bind('click.cc',function(){
				            $(this).focus();
			            });
			            return input.is(':checked');  
		            },  
		            message: 'Please check this field.'  
	            },
	            // class="easyui-validatebox" data-options="validType:'requireRadio[\'#ff input[name=radGlass]\', \'TFT or CF\']'"
	            // #ff 為 form id
		        requireRadio: {  
			        validator: function(value, param){  
				        var input = $(param[0]);
				        input.off('.requireRadio').on('click.requireRadio',function(){
					        $(this).focus();
				        });
				        return $(param[0] + ':checked').val() != undefined;
			        },  
			        message: 'Please choose option for {1}.'  
		        },
		        // <select id="test" class="easyui-combobox" name="state" style="width:200px;" required="true" validType="selectValueRequired['#test']">
                selectValueRequired: {  
                    validator: function(value,param){  
                        console.info($(param[0]).find("option:contains('"+value+"')").val()); 
                        return $(param[0]).find("option:contains('"+value+"')").val() != '';  
                    },  
                    message: 'select value required.'  
                },
		        // <select id="test" class="easyui-combobox" name="state" style="width:200px;" required="true" validType="selectValueRequired['#test']">
                selectValueRequired: {  
                    validator: function(value,param){  
                        console.info($(param[0]).find("option:contains('"+value+"')").val()); 
                        return $(param[0]).find("option:contains('"+value+"')").val() != '';  
                    },  
                    message: 'select value required.'  
                },
                // <input class="easyui-datebox" id="TimeFrom" required data-options="validType:'md[\'2000-01-01\',\'2020-01-01\']'" />
                md: {
                    validator: function(value, param){
                        var d1, d2, d3;
                        
                        d3 = $.fn.datebox.defaults.parser(value);
                        if (param == undefined){
                            return ($.fn.datebox.defaults.parser(value));
                        }
                        else if (param.length > 1){
                            d1 = $.fn.datebox.defaults.parser(param[0]);
                            d2 = $.fn.datebox.defaults.parser(param[1]);
                            return d3>=d1 && d3<=d2;
                        }
                        else if (param.length > 0){
                            d1 = $.fn.datebox.defaults.parser(param[0]);
                            return d3>=d1;
                        }
                    }//,
                    //message: 'The date must be less than or equals to {0}.'
                }
			});// JScript 檔

