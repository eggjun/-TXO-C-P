﻿// JScript 檔

$.extend({
    getUrlParams: function(){
        var vars = [], hash;
        if (window.location.href.indexOf('?') > -1){
            var url = window.location.href;
            if (url.indexOf('#') > 0 ) {url = url.substring(0, url.indexOf('#'));}
            var hashes = url.slice(url.indexOf('?') + 1).split('&');
            for(var i = 0; i < hashes.length; i++){
                hash = hashes[i].split('=');
                vars.push(hash[0]);
                vars[hash[0]] = hash[1];
            }
        }
        return vars;
    },
    getUrlParam: function(name){
        if ($.getUrlParams().length == 0)
            return "";
        else
            return $.getUrlParams()[name];
    }    
});