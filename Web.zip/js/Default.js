﻿
// 沒有加則 tree 的圖形很難看或 Close tag 的前面都會有空的 icon 區域
Ext.BLANK_IMAGE_URL = 'img/s.gif';

RsPanel = Ext.extend(Ext.Panel, {
    closable: true,
    autoScroll: false,   //調整不要Scroll Bar

    initComponent: function () {
        var ps = this.cclass.split('.');
        this.title = ps[ps.length - 1];

        RsPanel.superclass.initComponent.call(this);
    }
});

MainPanel = function () {
    MainPanel.superclass.constructor.call(this, {
        id: 'rs-body',
        region: 'center',
        margins: '0 5 0 0',
        resizeTabs: false,  // 設為 false 會依實際字串長短
        //minTabWidth: 130,
        //tabWidth: 130,
        autoScroll: true,
        plugins: new Ext.ux.TabCloseMenu(),
        enableTabScroll: true,
        activeTab: 0
    });
};
var CurrentSearchCls = '';
Ext.extend(MainPanel, Ext.TabPanel, {
    loadClass: function (href, cls, headerText, reload) {
        var clsparts = cls.split('.');
        var icon;

        // 開新視窗
        // cls ==> open.name
        if ( clsparts[0] == "open"){
            newWin = window.open(String.format(href, urlHost), clsparts[1], config='resizable=1,toolbar=0,menubar=0,location=0');
            // delay 500 ms 後再呼叫 focus()
            setTimeout(delay, 500);        
            function delay(){ 
                newWin.focus();
            }
            return true;
        }

        var id = 'rs-' + cls;
        var tab = this.getComponent(id);
        if (tab) { // tab 可以找到 (已存在)
            this.setActiveTab(tab);
            // 第一次以後再按同一個功能要刷新 (同子頁但條件不同)刷新內容
            //alert(reload);
            if (reload) {
               tab.body.dom.innerHTML = '<iframe name="frame' + cls + '" src="' +  href + '" frameborder="0" width="100%" height="100%" id="ifrmContent"><p>Your browser doesn\'t support/allow iframes   </p></iframe>'; 
            }
            //debugger;
            tab.setTitle( headerText);
        }
        else {
            var p = this.add(new RsPanel({
                id: id,
                cclass: cls,
                title: headerText,
                fitToFrame: true,
                //autoLoad: autoLoad,
                tabWidth: 500,
                html: '<iframe name="frame' + cls + '" src="' + href + '" frameborder="0" width="100%" height="100%" id="ifrmContent"><p>Your browser doesn\'t support/allow iframes   </p></iframe>'
                //,
                //iconCls: RS.icons[icon]
            }));
            // tab 要顯示的 title
            p.title = headerText;
            //p.html = '<iframe name="frame' + cls + '" src="' + href + '" frameborder="0" width="100%" height="100%" id="ifrmContent"><p>Your browser doesn\'t support/allow iframes   </p></iframe>';
//            //alert(this.tabWidth);
//            if ( tabWidth > 0)
//                this.tabWidth = tabWidth;
//            this.tabTip = 'aaaaa';
//            //alert(this.tabWidth);

            this.setActiveTab(p);
        }
    }
});



