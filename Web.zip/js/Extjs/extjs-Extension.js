﻿Ext.apply(Ext.form.VTypes, {
    // Time ~ vtype validation function
    time: function (val, field) {
        return /^(0[0-9]|1[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9])(\s[a|p]m)$/i.test(val);
    },
    // vtype Text property: The error text to display when the validation function returns false
    timeText: 'Not a valid time. Must be in the format "12:34:00 am".',
    // vtype Mask property: The keystroke filter mask
    timeMask: /[\d\s:amp]/i,

    //    // Date ~ vtype validation function
    //    date: function (val, field) {
    //        return /^\d{1,2}(\-|\/|\.)\d{1,2}\1\d{4}$/.test(val);
    //    },
    //    // vtype Text property: The error text to display when the validation function returns false
    //    dateText: 'Not a valid date.',
    //    // vtype Mask property: The keystroke filter mask
    //    dateMask: /[\d\s:amp]/i,


    // Number ~
    number: function (val, field) {
        return /^\d+|(0.\d+)|(\d+.\d+)$/.test(val);
    },
    numberText: 'Not a valid number.',
    numberMask: /[\d\.]/i,  // 除了這裡的字元外其它的不能輸入


    // IP Address ~
    ip: function (v) {
        return /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(v);
    },
    ipText: 'Must be a numeric IP address',
    ipMask: /[\d\.]/i
});


Ext.getUrlParam = function (param) {
    var params = Ext.urlDecode(location.search.substring(1));
    return param ? params[param] : params;
};


/**
* Copyright(c) 2011
*
* Licensed under the terms of the Open Source LGPL 3.0
* http://www.gnu.org/licenses/lgpl.html
* @author Greivin Britton, brittongr@gmail.com
*     
* @changes
* No currency symbol by default    
* No decimalPrecision in config
* Supporting any character as thousand separator
* Improved getFormattedValue
* Removed unnecessary code to create format template, now using float.toFixed(this.decimalPrecission)    
*/

Ext.ux.NumericField = function (config) {
    var defaultConfig =
    {
        style: 'text-align:right;'
    };

    Ext.ux.NumericField.superclass.constructor.call(this, Ext.apply(defaultConfig, config));

    //Only if thousandSeparator doesn't exists is assigned when using decimalSeparator as the same as thousandSeparator
    if (this.useThousandSeparator && this.decimalSeparator == ',' && Ext.isEmpty(config.thousandSeparator))
        this.thousandSeparator = '.';
    else
        if (this.allowDecimals && this.thousandSeparator == '.' && Ext.isEmpty(config.decimalSeparator))
            this.decimalSeparator = ',';

    this.onFocus = this.onFocus.createSequence(this.onFocus);
};

// currency type
Ext.extend(Ext.ux.NumericField, Ext.form.NumberField,
{
    currencySymbol: null,
    useThousandSeparator: true,
    thousandSeparator: ',',
    alwaysDisplayDecimals: false,
    setValue: function (v) {
        Ext.ux.NumericField.superclass.setValue.call(this, v);

        this.setRawValue(this.getFormattedValue(this.getValue()));
    },
    /**
    * No more using Ext.util.Format.number, Ext.util.Format.number in ExtJS versions
    * less thant 4.0 doesn't allow to use a different thousand separator than "," or "."
    * @param {Number} v
    */
    getFormattedValue: function (v) {
        if (Ext.isEmpty(v) || !this.hasFormat())
            return v;
        else {
            var neg = null;

            v = (neg = v < 0) ? v * -1 : v;
            v = this.allowDecimals && this.alwaysDisplayDecimals ? v.toFixed(this.decimalPrecision) : v;

            if (this.useThousandSeparator) {
                if (this.useThousandSeparator && Ext.isEmpty(this.thousandSeparator))
                    throw ('NumberFormatException: invalid thousandSeparator, property must has a valid character.');

                if (this.thousandSeparator == this.decimalSeparator)
                    throw ('NumberFormatException: invalid thousandSeparator, thousand separator must be different from decimalSeparator.');

                var v = String(v);

                var ps = v.split('.');
                ps[1] = ps[1] ? ps[1] : null;

                var whole = ps[0];

                var r = /(\d+)(\d{3})/;

                var ts = this.thousandSeparator;

                while (r.test(whole))
                    whole = whole.replace(r, '$1' + ts + '$2');

                v = whole + (ps[1] ? this.decimalSeparator + ps[1] : '');
            }

            return String.format('{0}{1}{2}', (neg ? '-' : ''), (Ext.isEmpty(this.currencySymbol) ? '' : this.currencySymbol + ' '), v);
        }
    },
    /**
    * overrides parseValue to remove the format applied by this class
    */
    parseValue: function (v) {
        //Replace the currency symbol and thousand separator
        return Ext.ux.NumericField.superclass.parseValue.call(this, this.removeFormat(v));
    },
    /**
    * Remove only the format added by this class to let the superclass validate with it's rules.
    * @param {Object} v
    */
    removeFormat: function (v) {
        if (Ext.isEmpty(v) || !this.hasFormat())
            return v;
        else {
            v = v.replace(this.currencySymbol + ' ', '');

            v = this.useThousandSeparator ? v.replace(new RegExp('[' + this.thousandSeparator + ']', 'g'), '') : v;
            //v = this.allowDecimals && this.decimalPrecision > 0 ? v.replace(this.decimalSeparator, '.') : v;

            return v;
        }
    },
    /**
    * Remove the format before validating the the value.
    * @param {Number} v
    */
    getErrors: function (v) {
        return Ext.ux.NumericField.superclass.getErrors.call(this, this.removeFormat(v));
    },
    hasFormat: function () {
        return this.decimalSeparator != '.' || this.useThousandSeparator == true || !Ext.isEmpty(this.currencySymbol) || this.alwaysDisplayDecimals;
    },
    /**
    * Display the numeric value with the fixed decimal precision and without the format using the setRawValue, don't need to do a setValue because we don't want a double
    * formatting and process of the value because beforeBlur perform a getRawValue and then a setValue.
    */
    onFocus: function () {
        this.setRawValue(this.removeFormat(this.getRawValue()));
    }
});
Ext.reg('numericfield', Ext.ux.NumericField);







/*!
* Ext JS Library 3.3.1
* Copyright(c) 2006-2010 Sencha Inc.
* licensing@sencha.com
* http://www.sencha.com/license
*/
Ext.ns('Ext.ux.grid');

/**
* @class Ext.ux.grid.CheckColumn
* @extends Ext.grid.Column
* <p>A Column subclass which renders a checkbox in each column cell which toggles the truthiness of the associated data field on click.</p>
* <p><b>Note. As of ExtJS 3.3 this no longer has to be configured as a plugin of the GridPanel.</b></p>
* <p>Example usage:</p>
* <pre><code>
var cm = new Ext.grid.ColumnModel([{
header: 'Foo',
...
},{
xtype: 'checkcolumn',
header: 'Indoor?',
dataIndex: 'indoor',
width: 55
}
]);

// create the grid
var grid = new Ext.grid.EditorGridPanel({
...
colModel: cm,
...
});
* </code></pre>
* In addition to toggling a Boolean value within the record data, this
* class toggles a css class between <tt>'x-grid3-check-col'</tt> and
* <tt>'x-grid3-check-col-on'</tt> to alter the background image used for
* a column.
*/
Ext.ux.grid.CheckColumn = Ext.extend(Ext.grid.Column, {

    /**
    * @private
    * Process and refire events routed from the GridView's processEvent method.
    */
    processEvent: function (name, e, grid, rowIndex, colIndex) {
        if (name == 'mousedown') {
            e.stopEvent();
            var record = grid.store.getAt(rowIndex);
            record.set(this.dataIndex, !record.data[this.dataIndex]);
            return false; // Cancel row selection.
        } else {
            return Ext.grid.ActionColumn.superclass.processEvent.apply(this, arguments);
        }
    },

    renderer: function (v, p, record) {
        p.css += ' x-grid3-check-col-td';
        return String.format('<div class="x-grid3-check-col{0}">&#160;</div>', v ? '-on' : '');
    },

    // Deprecate use as a plugin. Remove in 4.0
    init: Ext.emptyFn
});

// register ptype. Deprecate. Remove in 4.0
Ext.preg('checkcolumn', Ext.ux.grid.CheckColumn);

// backwards compat. Remove in 4.0
Ext.grid.CheckColumn = Ext.ux.grid.CheckColumn;

// register Column xtype
Ext.grid.Column.types.checkcolumn = Ext.ux.grid.CheckColumn;