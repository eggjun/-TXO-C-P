﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;



public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Request.Cookies["8AR2RUserName"] == null)  //Request.QueryString["user_id"] == null
        {
            Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check.asp");
        }
        else
        {
            try
            {
                Label label1 = (Label)this.FindControl("Label1");
                label1.Text = HttpContext.Current.Request.Cookies["8AR2RUserID"].Value + " / " + HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["8AR2RUserName"].Value, Encoding.GetEncoding("big5")) + " / " + HttpContext.Current.Request.Cookies["8AR2RDept"].Value; //+ HttpContext.Current.Request.Cookies["8A_R2R_User_Name"].Value;  //   Request.QueryString["user_name"]
            }
            catch
            {
                Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check.asp");
            }
       }

        //避免登出後還可以用上一頁回來繼續使用
        HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        HttpContext.Current.Response.Cache.SetNoServerCaching();
        HttpContext.Current.Response.Cache.SetNoStore();
        Session.Clear();
        //Request.QueryString["user_id"].ToString() + HttpUtility.UrlDecode(Request.QueryString["user_name"], Encoding.GetEncoding("utf-8"))
    }

    protected void SendToEmail(object sender, EventArgs e)
    {

        HttpContext.Current.Response.Cookies["8AR2RUserID"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
        HttpContext.Current.Response.Cookies["8AR2RUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
        HttpContext.Current.Response.Cookies["8AR2RDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
        HttpContext.Current.Response.Cookies["8AR2RUserID"].Expires = DateTime.Now.AddDays(-1);
        HttpContext.Current.Response.Cookies["8AR2RUserName"].Expires = DateTime.Now.AddDays(-1);
        HttpContext.Current.Response.Cookies["8AR2RDept"].Expires = DateTime.Now.AddDays(-1);

        Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check.asp");
    }
}
