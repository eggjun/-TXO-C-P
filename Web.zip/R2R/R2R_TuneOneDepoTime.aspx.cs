﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Text;


public partial class TuneOneDepoTime : System.Web.UI.Page
{
    String[] Fix_EQP_ID = { "AFSPT100", "AFSPT200", "AFSPT300", "AFSPT400", "AFSPT500", "AFSPT600" };
    String P4_Click_EQP_ID;

    DataTable data_table = new DataTable();
    DataTable DefaultValue_table = new DataTable();

    int Select_Recipe_num = 0;  //此EQP有多少Recipe
    int Select_Recipe_Index = 0;  //選擇的Recipe在list的位置

    string[] Value_split;

    protected void Page_Load(object sender, EventArgs e)
    {
        //初始化Session，控制選擇EQP_ID
        if (Request.QueryString["P4_Click_EQP_ID"] == null)  
        {
            P4_Click_EQP_ID = Fix_EQP_ID[0];
        }
        else
        {
            P4_Click_EQP_ID = Request.QueryString["P4_Click_EQP_ID"];
        }

        //完成DB更新
        if (HttpContext.Current.Request.Cookies["UpdateDept"] != null && Session["P4_Final_Value"] != null && Session["P4_Done_Test"] != null && Session["P4_Done_Test"].ToString() == "1")
        {
            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));

            //開啟資料庫
            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
            MySqlConnection conn_act = new MySqlConnection(connection_act);
            conn_act.Open();

            //取得時間
            DateTime dt = DateTime.Now; // 取得現在時間
            String Now_Time = dt.ToString("yyyy-MM-dd HH:mm:ss"); // 轉成字串

            //MySql語句1
            string sqlQuery_act = "UPDATE `spt_depo_time` SET Recipe_Depo_Time = \"" + Session["P4_Final_Value"] + "\", Modified_Flag=\"true\" ,Update_User=\"" + user_name + "\",Update_Time = \"" + Now_Time + "\", SVM_Flag=\"wait\" " +
                                  " WHERE EQP_ID=\"" + P4_Click_EQP_ID + "\"";
            //執行
            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
            cmd_act.ExecuteNonQuery();


            //紀錄
            string[] Before_Value = Session["P4_Before_Value"].ToString().Split(','); //要顯示的資料
            string[] After_Value = Session["P4_Final_Value"].ToString().Split(','); //要顯示的資料
            string[] Recipe_Name_Order = Session["P4_Recipe_Name_Order"].ToString().Split(','); //要顯示的資料

            //讀取Default Value用
            sqlQuery_act = "SELECT Recipe_Name,Default_Value FROM `spt_recipe_depo_time` WHERE EQP_ID='" + P4_Click_EQP_ID + "'";
            cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
            MySqlDataAdapter data_act = new MySqlDataAdapter();
            data_act.SelectCommand = cmd_act;
            data_act.Fill(DefaultValue_table);

            for (int i = 0; i < Before_Value.Length; i++)
            {
                if (Before_Value[i] != After_Value[i])  //前後值不一樣，新增進紀錄
                {
                    //先找到Default_Value
                    string DV = "";
                    for (int j = 0; j < DefaultValue_table.Rows.Count; j++)
                    {
                        if (DefaultValue_table.Rows[j][0].ToString() == Recipe_Name_Order[i])
                        {
                            DV = DefaultValue_table.Rows[j][1].ToString();
                        }
                    }

                    sqlQuery_act = "REPLACE INTO `spt_depo_time_log` (EQP_ID,Recipe_Name,Default_Value,Depo_Time_Before,Depo_Time_After,Update_User,Update_Time)" +
                                   "VALUES (\"" + P4_Click_EQP_ID + "\",\"" + Recipe_Name_Order[i] + "\",\"" + DV + "\",\"" + Before_Value[i] + "\",\"" + After_Value[i] + "\",\"" + user_name + "\" , \"" + Now_Time + "\")";
                    cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                    cmd_act.ExecuteNonQuery();
                }
            }


            conn_act.Close();

            //Response.Write(sqlQuery_act);

            //清空session
            ClearSession();

            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);

        }


        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();
        //MySql查詢語句：查資料
        string sqlQuery = "SELECT * FROM `spt_depo_time` WHERE EQP_ID='" + P4_Click_EQP_ID + "'";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(data_table);
        conn.Close();


        DropDownList List1 = (DropDownList)this.FindControl("DropDownList1");         //找到元件
        string[] Recipe_split = data_table.Rows[0][6].ToString().Split(','); //要顯示的Recipe

        if (!IsPostBack)
        {
            for (int i = 0; i < Recipe_split.Length; i++)
            {
                List1.Items.Add(new ListItem(Recipe_split[i]));
            }

            if (Request.QueryString["Select_Recipe_Index"] != null)
            {
                List1.Text = Recipe_split[int.Parse(Request.QueryString["Select_Recipe_Index"])];
            }
        }


        //顯示表格
        Table Table1 = (Table)this.FindControl("Table1");         //找到元件

        for (int i = -1; i < 1; i++)
        {
            if (i == -1)
            {
                TableRow row_head = new TableRow();
                TableCell cell_head = new TableCell();
                cell_head.Text = "現在(調前)秒數";
                cell_head.Font.Size = 12;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                cell_head.BackColor = ColorTranslator.FromHtml("#FFEE99"); //設定背景顏色
                cell_head.Width = new Unit("200px");  //寬度
                cell_head.Height = new Unit("50px");  //高度
                row_head.Cells.Add(cell_head);

                cell_head = new TableCell();
                cell_head.Text = "調後秒數";
                cell_head.Font.Size = 12;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                cell_head.BackColor = ColorTranslator.FromHtml("#FFEE99"); //設定背景顏色
                cell_head.Width = new Unit("200px");  //寬度
                cell_head.Height = new Unit("50px");  //高度
                row_head.Cells.Add(cell_head);

                Table1.Rows.Add(row_head);
            }
            else
            {
                if (Request.QueryString["Select_Recipe_Index"] != null)
                {
                    Select_Recipe_Index = int.Parse(Request.QueryString["Select_Recipe_Index"]);
                }

                Session["P4_Before_Value"] = data_table.Rows[0][1].ToString();
                Value_split = Session["P4_Before_Value"].ToString().Split(','); //要顯示的資料
                Select_Recipe_num = Value_split.Length;

                TableRow row_head = new TableRow();
                TableCell cell_head = new TableCell();
                cell_head.Text = Value_split[Select_Recipe_Index];
                cell_head.Font.Size = 14;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.ForeColor = ColorTranslator.FromHtml("#3333CC");
                cell_head.Height = new Unit("50px");  //高度
                row_head.Cells.Add(cell_head);

                cell_head = new TableCell();
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.BackColor = ColorTranslator.FromHtml("#FFFFFF"); //設定背景顏色
                cell_head.Width = new Unit(100, UnitType.Pixel);
                TextBox textbox = new TextBox();
                textbox.ID = "TextBox_1";
                textbox.Text = (int.Parse(Value_split[Select_Recipe_Index])+1).ToString();  //之後要根據TGL讀值
                textbox.Font.Size = 12;  //字型
                textbox.Font.Bold = true;  //字體粗體
                textbox.ForeColor = ColorTranslator.FromHtml("#800000");
                textbox.Width = new Unit("60%");
                textbox.Height = new Unit("100%");
                textbox.Style["text-align"] = "center";
                textbox.Style["align"] = "center";
                cell_head.Controls.Add(textbox);
                row_head.Cells.Add(cell_head);


                Table1.Rows.Add(row_head);
            }
        }




        Session["P4_Click_EQP_ID"] = P4_Click_EQP_ID;//用來檢查上一次是按誰

        //做選定的EQP_ID 按鈕不同色
        if (P4_Click_EQP_ID == Fix_EQP_ID[0])
        {
            Button btn = (Button)this.FindControl("Button1");         //找到元件
            btn.BackColor = ColorTranslator.FromHtml("#40e0d0");
        }
        else if (P4_Click_EQP_ID == Fix_EQP_ID[1])
        {
            Button btn = (Button)this.FindControl("Button2");         //找到元件
            btn.BackColor = ColorTranslator.FromHtml("#40e0d0");
        }
        else if (P4_Click_EQP_ID == Fix_EQP_ID[2])
        {
            Button btn = (Button)this.FindControl("Button3");         //找到元件
            btn.BackColor = ColorTranslator.FromHtml("#40e0d0");
        }
        else if (P4_Click_EQP_ID == Fix_EQP_ID[3])
        {
            Button btn = (Button)this.FindControl("Button4");         //找到元件
            btn.BackColor = ColorTranslator.FromHtml("#40e0d0");
        }
        else if (P4_Click_EQP_ID == Fix_EQP_ID[4])
        {
            Button btn = (Button)this.FindControl("Button5");         //找到元件
            btn.BackColor = ColorTranslator.FromHtml("#40e0d0");
        }
        else if (P4_Click_EQP_ID == Fix_EQP_ID[5])
        {
            Button btn = (Button)this.FindControl("Button6");         //找到元件
            btn.BackColor = ColorTranslator.FromHtml("#40e0d0");
        }

        Response.AppendHeader("Refresh", "30");
    }

    //確定調整
    protected void Button_Adjust_event(object sender, EventArgs e)
    {
        TextBox TextBox_1 = (TextBox)FindControl("TextBox_1");

        string Final_Value = "";


        for (int num = 0; num < Select_Recipe_num; num++)
        {
            if (num == 0)
            {
                if (Select_Recipe_Index == num)
                {
                    Final_Value = TextBox_1.Text;
                }
                else
                {
                    Final_Value = int.Parse(Value_split[num]).ToString();
                }

            }
            else
            {
                if (Select_Recipe_Index == num)
                {
                    Final_Value = Final_Value + "," + TextBox_1.Text;
                }
                else
                {
                    Final_Value = Final_Value + "," + int.Parse(Value_split[num]).ToString();
                }
            }
        }

        Session["P4_Recipe_Name_Order"] = data_table.Rows[0][6].ToString();
        Session["P4_Final_Value"] = Final_Value;
        Session["P4_Done_Test"] = 1;

        //UAC認證
        Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_TuneOneDepoTime&P4_Click_EQP_ID=" + P4_Click_EQP_ID);
    }

    private void ClearSession()
    {
        Session["P4_Click_EQP_ID"] = null;

        Session["P4_Before_Value"] = null;
        Session["P4_Final_Value"] = null;
        Session["P4_Recipe_Name_Order"] = null;
        Session["P4_Done_Test"] = null;
    }

    protected void Button_1_event(object sender, EventArgs e)
    {
        P4_Click_EQP_ID = Fix_EQP_ID[0];
        ClearSession();
        Response.Redirect("R2R_TuneOneDepoTime.aspx?P4_Click_EQP_ID=" + P4_Click_EQP_ID);
    }

    protected void Button_2_event(object sender, EventArgs e)
    {
        P4_Click_EQP_ID = Fix_EQP_ID[1];
        ClearSession();
        Response.Redirect("R2R_TuneOneDepoTime.aspx?P4_Click_EQP_ID=" + P4_Click_EQP_ID);
    }

    protected void Button_3_event(object sender, EventArgs e)
    {
        P4_Click_EQP_ID = Fix_EQP_ID[2];
        ClearSession();
        Response.Redirect("R2R_TuneOneDepoTime.aspx?P4_Click_EQP_ID=" + P4_Click_EQP_ID);
    }

    protected void Button_4_event(object sender, EventArgs e)
    {
        P4_Click_EQP_ID = Fix_EQP_ID[3];
        ClearSession();
        Response.Redirect("R2R_TuneOneDepoTime.aspx?P4_Click_EQP_ID=" + P4_Click_EQP_ID);
    }

    protected void Button_5_event(object sender, EventArgs e)
    {
        P4_Click_EQP_ID = Fix_EQP_ID[4];
        ClearSession();
        Response.Redirect("R2R_TuneOneDepoTime.aspx?P4_Click_EQP_ID=" + P4_Click_EQP_ID);
    }

    protected void Button_6_event(object sender, EventArgs e)
    {
        P4_Click_EQP_ID = Fix_EQP_ID[5];
        ClearSession();
        Response.Redirect("R2R_TuneOneDepoTime.aspx?P4_Click_EQP_ID=" + P4_Click_EQP_ID);
    }


    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DropDownList List1 = (DropDownList)this.FindControl("DropDownList1");         //找到元件
        Response.Redirect("R2R_TuneOneDepoTime.aspx?P4_Click_EQP_ID=" + P4_Click_EQP_ID + "&Select_Recipe_Index=" + List1.SelectedIndex);
    }
}

