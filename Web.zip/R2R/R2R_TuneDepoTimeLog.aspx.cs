﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Drawing;



public partial class TuneDepoTimeLog : System.Web.UI.Page
{
    DataTable data_table = new DataTable();

    String[] Fix_EQP_ID = { "AFSPT100", "AFSPT200", "AFSPT300", "AFSPT400", "AFSPT500", "AFSPT600" };
    String P5_Click_EQP_ID;

    int Select_Recipe_num = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        //初始化Session，控制選擇EQP_ID
        if (Request.QueryString["P5_Click_EQP_ID"] == null)  //第10頁點的EQP_ID
        {
            P5_Click_EQP_ID = Fix_EQP_ID[0];
        }
        else
        {
            P5_Click_EQP_ID = Request.QueryString["P5_Click_EQP_ID"];
        }


        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        //MySql查詢語句：查target_life欄位
        string sqlQuery = "SELECT * FROM `spt_depo_time_log` WHERE EQP_ID='" + P5_Click_EQP_ID + "' order by Update_Time desc";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(data_table);
        conn.Close();


        //顯示表格
        Table Table1 = (Table)this.FindControl("Table1");         //找到元件

        //表格標頭
        TableRow row_head = new TableRow();

        for (int i = 0; i < data_table.Columns.Count; i++)
        {
            TableCell cell_head = new TableCell();
            cell_head.Text = data_table.Columns[i].ColumnName.ToString();
            cell_head.Font.Size = 12;  //字型
            cell_head.Font.Bold = true;  //字體粗體

            if (i == 2)
            {
                cell_head.BackColor = ColorTranslator.FromHtml("#FF9900"); //設定背景顏色
            }
            else if (i== 3 | i== 4)
            {
                cell_head.BackColor = ColorTranslator.FromHtml("#FF99CC"); //設定背景顏色
            }
            else if (i == 5 | i == 6)
            {
                cell_head.BackColor = ColorTranslator.FromHtml("#CCFFCC"); //設定背景顏色
            }
            else
            {
                cell_head.BackColor = ColorTranslator.FromHtml("#99CCFF"); //設定背景顏色
            }
 
            row_head.Cells.Add(cell_head);
            
        }

        Table1.Rows.Add(row_head);


        //Data
        for (int row_index = 0; row_index < data_table.Rows.Count; row_index++)
        {
            TableRow row = new TableRow();
            for (int column_index = 0; column_index < data_table.Columns.Count; column_index++)
            {

                TableCell cell1 = new TableCell();
                cell1.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                cell1.Font.Size = 12;  //字大小
                cell1.Font.Bold = true;  //字體粗體
                if (column_index == 3)
                {
                    cell1.ForeColor = ColorTranslator.FromHtml("#FF0000");
                }
                else if (column_index == 4)
                {
                    cell1.ForeColor = ColorTranslator.FromHtml("#008000");
                }
                else if (column_index == 5)
                {
                    cell1.ForeColor = ColorTranslator.FromHtml("#0000FF");

                }
                else
                {
                    cell1.ForeColor = ColorTranslator.FromHtml("#000000");
                }
                row.Cells.Add(cell1);
            }
            Table1.Rows.Add(row);
        }
        
    }

    protected void Button_1_event(object sender, EventArgs e)
    {
        P5_Click_EQP_ID = Fix_EQP_ID[0];
        Response.Redirect("R2R_TuneDepoTimeLog.aspx?P5_Click_EQP_ID=" + P5_Click_EQP_ID);
    }

    protected void Button_2_event(object sender, EventArgs e)
    {
        P5_Click_EQP_ID = Fix_EQP_ID[1];
        Response.Redirect("R2R_TuneDepoTimeLog.aspx?P5_Click_EQP_ID=" + P5_Click_EQP_ID);
    }

    protected void Button_3_event(object sender, EventArgs e)
    {
        P5_Click_EQP_ID = Fix_EQP_ID[2];
        Response.Redirect("R2R_TuneDepoTimeLog.aspx?P5_Click_EQP_ID=" + P5_Click_EQP_ID);
    }

    protected void Button_4_event(object sender, EventArgs e)
    {
        P5_Click_EQP_ID = Fix_EQP_ID[3];
        Response.Redirect("R2R_TuneDepoTimeLog.aspx?P5_Click_EQP_ID=" + P5_Click_EQP_ID);
    }

    protected void Button_5_event(object sender, EventArgs e)
    {
        P5_Click_EQP_ID = Fix_EQP_ID[4];
        Response.Redirect("R2R_TuneDepoTimeLog.aspx?P5_Click_EQP_ID=" + P5_Click_EQP_ID);
    }

    protected void Button_6_event(object sender, EventArgs e)
    {
        P5_Click_EQP_ID = Fix_EQP_ID[5];
        Response.Redirect("R2R_TuneDepoTimeLog.aspx?P5_Click_EQP_ID=" + P5_Click_EQP_ID);
    }

}

