﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Drawing;



public partial class RecipeSettingLog : Page
{
    DataTable column_table = new DataTable();
    DataTable data_table = new DataTable();

    String[] Fix_EQP_ID = { "AFSPT100", "AFSPT200", "AFSPT300", "AFSPT400", "AFSPT500", "AFSPT600" };
    String P10_Click_EQP_ID;

    int Select_Recipe_num = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        //初始化Session，控制選擇EQP_ID
        if (Request.QueryString["P10_Click_EQP_ID"] == null)  //第10頁點的EQP_ID
        {
            P10_Click_EQP_ID = Fix_EQP_ID[0];
        }
        else
        {
            P10_Click_EQP_ID = Request.QueryString["P10_Click_EQP_ID"];
        }


        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        //MySql查詢語句：查target_life欄位
        string sqlQuery = "SELECT Life_From,Life_To FROM `spt_target_life_range` WHERE EQP_ID='" + P10_Click_EQP_ID + "'";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset column_table中
        data.Fill(column_table);

        //------

        //MySql查詢語句：查資料
        sqlQuery = "SELECT * FROM `spt_recipe_depo_time_log` WHERE EQP_ID='" + P10_Click_EQP_ID + "'";

        //執行查詢
        cmd = new MySqlCommand(sqlQuery, conn);
        data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset data_table中
        data.Fill(data_table);

        conn.Close();


        //顯示表格
        Table Table1 = (Table)this.FindControl("Table1");         //找到元件

        //表格標頭
        TableRow row_head = new TableRow();

        for (int i = 0; i < data_table.Columns.Count; i++)
        {
            if (i == 3)
            {
                for (int x = 0; x < column_table.Rows.Count; x++)
                {
                    TableCell cell_head = new TableCell();
                    cell_head.Text = column_table.Rows[x][0] + "~" + column_table.Rows[x][1];
                    cell_head.Font.Size = 10;  //字型
                    cell_head.Font.Bold = true;  //字體粗體
                    cell_head.ForeColor = ColorTranslator.FromHtml("#3333CC");
                    cell_head.BackColor = ColorTranslator.FromHtml("#AAFFEE"); //設定背景顏色

                    cell_head.Width = new Unit((49 / column_table.Rows.Count).ToString() + "%");

                    row_head.Cells.Add(cell_head);
                }
            }
            else
            {
                TableCell cell_head = new TableCell();
                cell_head.Text = data_table.Columns[i].ColumnName.ToString();
                cell_head.Font.Size = 10;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.ForeColor = ColorTranslator.FromHtml("#3333CC");
                cell_head.BackColor = ColorTranslator.FromHtml("#CCFFFF"); //設定背景顏色

                if (i == 1 | i == 5)
                    cell_head.Width = new Unit("12%");
                else
                    cell_head.Width = new Unit("9%");


                row_head.Cells.Add(cell_head);
            }
        }

        Table1.Rows.Add(row_head);


        //Data
        for (int row_index = 0; row_index < data_table.Rows.Count; row_index++)
        {
            TableRow row = new TableRow();
            for (int column_index = 0; column_index < data_table.Columns.Count; column_index++)
            {

                if (column_index == 3)
                {
                    string[] value_split = data_table.Rows[row_index][column_index].ToString().Split(',');  //要顯示的資料
                    Select_Recipe_num = column_table.Rows.Count;

                    for (int num = 0; num < Select_Recipe_num; num++)
                    {
                        TableCell cell1 = new TableCell();
                        cell1.Font.Size = 10;  //字型
                        cell1.Text = value_split[num];  //要顯示的資料
                        row.Cells.Add(cell1);
                    }
                }
                else
                {
                    TableCell cell1 = new TableCell();
                    cell1.Font.Size = 10;  //字型
                    cell1.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                    row.Cells.Add(cell1);
                }
            }
            Table1.Rows.Add(row);
        }

    }

    protected void Button_1_event(object sender, EventArgs e)
    {
        P10_Click_EQP_ID = Fix_EQP_ID[0];
        Response.Redirect("R2R_RecipeSettingLog.aspx?P10_Click_EQP_ID=" + P10_Click_EQP_ID);
    }

    protected void Button_2_event(object sender, EventArgs e)
    {
        P10_Click_EQP_ID = Fix_EQP_ID[1];
        Response.Redirect("R2R_RecipeSettingLog.aspx?P10_Click_EQP_ID=" + P10_Click_EQP_ID);
    }

    protected void Button_3_event(object sender, EventArgs e)
    {
        P10_Click_EQP_ID = Fix_EQP_ID[2];
        Response.Redirect("R2R_RecipeSettingLog.aspx?P10_Click_EQP_ID=" + P10_Click_EQP_ID);
    }

    protected void Button_4_event(object sender, EventArgs e)
    {
        P10_Click_EQP_ID = Fix_EQP_ID[3];
        Response.Redirect("R2R_RecipeSettingLog.aspx?P10_Click_EQP_ID=" + P10_Click_EQP_ID);
    }

    protected void Button_5_event(object sender, EventArgs e)
    {
        P10_Click_EQP_ID = Fix_EQP_ID[4];
        Response.Redirect("R2R_RecipeSettingLog.aspx?P10_Click_EQP_ID=" + P10_Click_EQP_ID);
    }

    protected void Button_6_event(object sender, EventArgs e)
    {
        P10_Click_EQP_ID = Fix_EQP_ID[5];
        Response.Redirect("R2R_RecipeSettingLog.aspx?P10_Click_EQP_ID=" + P10_Click_EQP_ID);
    }

   



}

