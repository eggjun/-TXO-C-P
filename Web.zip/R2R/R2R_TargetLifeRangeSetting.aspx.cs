﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Text;


public partial class TargetLifeRangeSetting : System.Web.UI.Page
{
    DataTable data_table = new DataTable();

    String[] Fix_EQP_ID = { "AFSPT100", "AFSPT200", "AFSPT300", "AFSPT400", "AFSPT500", "AFSPT600" };
    String P11_Click_EQP_ID;


    protected void Page_Load(object sender, EventArgs e)
    {
        
        //初始化Session，控制選擇EQP_ID
        if (Request.QueryString["P11_Click_EQP_ID"] == null)  //第11頁點的EQP_ID
        {
            P11_Click_EQP_ID = Fix_EQP_ID[0];
        }
        else
        {
            P11_Click_EQP_ID = Request.QueryString["P11_Click_EQP_ID"];
        }

        if (Session["Act"] != null)
        {
            switch (Session["Act"].ToString())
            {
                case "0":  //新增指令
                    {
                        //----**************要加入判斷部門的部分-*************---


                        if (HttpContext.Current.Request.Cookies["UpdateDept"] != null & Session["T1"] != null & Session["T2"] != null)
                        {
                            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));


                            //開啟資料庫
                            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
                            MySqlConnection conn_act = new MySqlConnection(connection_act);
                            conn_act.Open();

                            //取得時間
                            DateTime dt = DateTime.Now; // 取得現在時間
                            String Now_Time = dt.ToString("yyyy-MM-dd HH:mm:ss"); // 轉成字串

                            //MySql語句
                            string sqlQuery_act = "REPLACE INTO `spt_target_life_range` (EQP_ID,Life_From,Life_To,Create_User,Create_Time,Update_User,Update_Time)" +
                                                  "VALUES (\"" + P11_Click_EQP_ID + "\",\"" + Session["T1"] + "\",\"" + Session["T2"] + "\",\"" + user_name + "\",\"" + Now_Time + "\",\"" + user_name + "\",\"" + Now_Time + "\") ";

                            //執行
                            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();
                            conn_act.Close();


                            //Response.Write(sqlQuery_act);

                            //清空session
                            ClearSession();

                            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            //HttpContext.Current.Response.Cookies["UpdateUserName"].Value = null;
                            //HttpContext.Current.Response.Cookies["UpdateDept"].Value = null;
                            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
                            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);

                            //重整網頁
                            //Response.Redirect("R2R_TargetLifeRangeSetting.aspx");
                        }
                    }
                    break;
                case "1":  //修改指令
                    {
                        //----**************要加入判斷部門的部分-*************---


                        if (HttpContext.Current.Request.Cookies["UpdateDept"] != null && Session["T1"] != null && Session["T2"] != null && Session["Done_Test"].ToString() == "1")
                        {
                            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));

                            //開啟資料庫
                            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
                            MySqlConnection conn_act = new MySqlConnection(connection_act);
                            conn_act.Open();

                            //取得時間
                            DateTime dt = DateTime.Now; // 取得現在時間
                            String Now_Time = dt.ToString("yyyy-MM-dd HH:mm:ss"); // 轉成字串

                            //MySql語句
                            string sqlQuery_act = "UPDATE `spt_target_life_range` SET Life_From=\"" + Session["T1"] + "\",Life_To=\"" + Session["T2"] +"\",Update_User=\"" + user_name + "\",Update_Time = \"" + Now_Time +
                                                  "\" WHERE EQP_ID=\"" + P11_Click_EQP_ID + "\" AND Life_From=\"" + Session["T1raw"] + "\" AND Life_To=\"" + Session["T2raw"] + "\"";

                            //執行
                            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();
                            conn_act.Close();

                            //Response.Write(sqlQuery_act);

                            //清空session
                            ClearSession();

                            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            //HttpContext.Current.Response.Cookies["UpdateUserName"].Value = null;
                            //HttpContext.Current.Response.Cookies["UpdateDept"].Value = null;
                            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
                            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);
                        }
                    }
                    break;
                /*case "2":  //刪除指令
                    {
                        //----**************要加入判斷部門的部分-*************---


                        if (HttpContext.Current.Request.Cookies["UpdateDept"] != null && Session["T1raw"] != null && Session["T2raw"] != null)
                        {
                            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));

                            //開啟資料庫
                            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
                            MySqlConnection conn_act = new MySqlConnection(connection_act);
                            conn_act.Open();

                            //MySql語句
                            string sqlQuery_act = "DELETE FROM `spt_target_life_range` WHERE EQP_ID=\"" + P11_Click_EQP_ID + "\" AND Life_From=\"" + Session["T1raw"] + "\" AND Life_To=\"" + Session["T2raw"] + "\"";

                            //執行
                            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();
                            conn_act.Close();

                            //Response.Write(sqlQuery_act);

                            //清空session
                            ClearSession();

                            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            //HttpContext.Current.Response.Cookies["UpdateUserName"].Value = null;
                            //HttpContext.Current.Response.Cookies["UpdateDept"].Value = null;
                            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
                            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);

                        }
                    }
                    break;*/
            }  
        }
        

        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        //MySql查詢語句
        string sqlQuery = "SELECT * FROM `spt_target_life_range` WHERE EQP_ID='" + P11_Click_EQP_ID + "'";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset data_table中
        data.Fill(data_table);

        conn.Close();

        //Response.Write(data_table.Columns[0].ColumnName);
        //Response.Write(data_table.Rows[0][1].ToString());


        //顯示表格
        Table Table1 = (Table)this.FindControl("Table1");         //找到元件
        Table1.BorderStyle = BorderStyle.Solid;
        Table1.BorderWidth = 2;


        //表格標頭
        TableRow row_head = new TableRow();
        for (int i = 0; i < data_table.Columns.Count; i++)
        {
            TableCell cell_head = new TableCell();

            cell_head.Text = data_table.Columns[i].ColumnName.ToString();
            cell_head.Font.Bold = true;  //字體粗體
            cell_head.Font.Size = FontUnit.XLarge;  //大字型
            cell_head.ForeColor = Color.White;
            cell_head.BackColor = ColorTranslator.FromHtml("#4CAF50"); //設定背景顏色
            row_head.Cells.Add(cell_head);

        }

        //欄位修改
        TableCell cell_temp = new TableCell();

        cell_temp.Text = "資料調整";
        cell_temp.Font.Bold = true;  //字體粗體
        cell_temp.Font.Size = FontUnit.XLarge;  //大字型
        cell_temp.ForeColor = Color.White;
        cell_temp.BackColor = ColorTranslator.FromHtml("#4CAF50"); //設定背景顏色
        row_head.Cells.Add(cell_temp);

        Table1.Rows.Add(row_head);


        //Data
        for (int row_index = 0; row_index < data_table.Rows.Count; row_index++)
        {
            TableRow row = new TableRow();
            for (int column_index = 0; column_index < data_table.Columns.Count; column_index++)
            {
                TableCell cell1 = new TableCell();

                //修改部分，要將文字改成Textbox
                if (Session["Act"] != null && Session["Act"].ToString() == "1" && Session["Done_Test"].ToString() == "0" && int.Parse(Session["select_index"].ToString()) == row_index && (column_index == 1 | column_index== 2))
                {
                    TextBox textbox = new TextBox();
                    textbox.ID = "TextBox_Adjust_" + Convert.ToString(column_index);
                    textbox.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                    cell1.Controls.Add(textbox);
                }
                else
                {
                    cell1.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                    cell1.Font.Bold = true;  //字體粗體
                }


                row.Cells.Add(cell1);

            }

            //調區間按鈕
            TableCell btnCell = new TableCell();

            Button btn = new Button();

            //先判斷有沒有null，使用&&
            if (Session["Act"] != null && Session["Act"].ToString() == "1" && Session["Done_Test"].ToString() == "0" && int.Parse(Session["select_index"].ToString()) == row_index)
            {
                btn.Text = "更新";
            }
            else
            {
                btn.Text = "修改";
            }


            btn.ID = "Button_Adjust_" + Convert.ToString(row_index);
            btn.Click += new EventHandler(Button_Adjust);
            btnCell.Controls.Add(btn);
            row.Cells.Add(btnCell);



            //刪除按鈕
            //btnCell = new TableCell();
            /*btn = new Button();
            btn.Text = "刪除";

            btn.ID = "Button_Delete_" + Convert.ToString(row_index);
            btn.Click += new EventHandler(Button_Delete);
            btn.Attributes.CssStyle.Add("margin-left", "10px");
            btn.Attributes.Add("onclick", "return confirm('是否確定要刪除?');");
            btnCell.Controls.Add(btn);
            row.Cells.Add(btnCell);
            */


            Table1.Rows.Add(row);
        }

    }

    //修改按鈕
    protected void Button_Adjust(object sender, EventArgs e)
    {
        string Button_ID = ((Button)sender).ID;
        int select_index = int.Parse(Button_ID.ToString().Split('_')[2]);

        Button button_now = (Button)FindControl(Button_ID);
        TextBox TextBox_Adjust_1 = (TextBox)FindControl("TextBox_Adjust_1");
        TextBox TextBox_Adjust_2 = (TextBox)FindControl("TextBox_Adjust_2");



        Session["Act"] = 1;
        Session["select_index"] = select_index;
        Session["Done_Test"] = 0;

        if (button_now.Text == "更新")
        {
            Session["T1"] = TextBox_Adjust_1.Text;
            Session["T2"] = TextBox_Adjust_2.Text;
            Session["T1raw"] = data_table.Rows[select_index][1].ToString();
            Session["T2raw"] = data_table.Rows[select_index][2].ToString();
            Session["Done_Test"] = 1;

            //UAC認證
            Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_TargetLifeRangeSetting&P11_Click_EQP_ID=" + P11_Click_EQP_ID);
        }

        Response.Redirect("R2R_TargetLifeRangeSetting.aspx?P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }

    //刪除按鈕
    /*protected void Button_Delete(object sender, EventArgs e)
    {
        string Button_ID = ((Button)sender).ID;
        int select_index = int.Parse(Button_ID.ToString().Split('_')[2]);

        Session["Act"] = 2;
        Session["select_index"] = select_index;
        Session["T1raw"] = data_table.Rows[select_index][1].ToString();
        Session["T2raw"] = data_table.Rows[select_index][2].ToString();


        //UAC認證
        Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_TargetLifeRangeSetting&P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }*/

    protected void Button_1_event(object sender, EventArgs e)
    {
        P11_Click_EQP_ID = Fix_EQP_ID[0];
        ClearSession();
        Response.Redirect("R2R_TargetLifeRangeSetting.aspx?P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }

    protected void Button_2_event(object sender, EventArgs e)
    {
        P11_Click_EQP_ID = Fix_EQP_ID[1];
        ClearSession();
        Response.Redirect("R2R_TargetLifeRangeSetting.aspx?P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }

    protected void Button_3_event(object sender, EventArgs e)
    {
        P11_Click_EQP_ID = Fix_EQP_ID[2];
        ClearSession();
        Response.Redirect("R2R_TargetLifeRangeSetting.aspx?P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }

    protected void Button_4_event(object sender, EventArgs e)
    {
        P11_Click_EQP_ID = Fix_EQP_ID[3];
        ClearSession();
        Response.Redirect("R2R_TargetLifeRangeSetting.aspx?P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }

    protected void Button_5_event(object sender, EventArgs e)
    {
        P11_Click_EQP_ID = Fix_EQP_ID[4];
        ClearSession();
        Response.Redirect("R2R_TargetLifeRangeSetting.aspx?P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }

    protected void Button_6_event(object sender, EventArgs e)
    {
        P11_Click_EQP_ID = Fix_EQP_ID[5];
        ClearSession();
        Response.Redirect("R2R_TargetLifeRangeSetting.aspx?P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }

    protected void Button_Add_event(object sender, EventArgs e)
    {
        TextBox TextBox1 = (TextBox)this.FindControl("TextBox1");
        TextBox TextBox2 = (TextBox)this.FindControl("TextBox2");

        Session["Act"]=0;
        Session["T1"] = TextBox1.Text;
        Session["T2"] = TextBox2.Text;


        Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_TargetLifeRangeSetting&P11_Click_EQP_ID=" + P11_Click_EQP_ID);
    }

    private void ClearSession()
    {
        Session["Act"] = "";
        Session["T1"] = "";
        Session["T2"] = "";
        Session["T1raw"] = "";
        Session["T2raw"] = "";
        Session["Done_Test"] = "";
    }

}

