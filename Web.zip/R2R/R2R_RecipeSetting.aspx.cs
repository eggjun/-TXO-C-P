﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Drawing;
using System.Text;


public partial class RecipeSetting : Page
{
    DataTable column_table = new DataTable();
    DataTable data_table = new DataTable();

    String[] Fix_EQP_ID = { "AFSPT100", "AFSPT200", "AFSPT300", "AFSPT400", "AFSPT500", "AFSPT600" };
    String P9_Click_EQP_ID;

    int Select_Recipe_num = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        //初始化Session，控制選擇EQP_ID
        if (Request.QueryString["P9_Click_EQP_ID"] == null)  //第9頁點的EQP_ID
        {
            P9_Click_EQP_ID = Fix_EQP_ID[0];
        }
        else
        {
            P9_Click_EQP_ID = Request.QueryString["P9_Click_EQP_ID"];
        }

        if (Session["Act"] != null && HttpContext.Current.Request.Cookies["UpdateDept"] != null)
        {
            switch (Session["Act"].ToString())
            {
                case "0":  //新增指令
                    {
                        //----**************要加入判斷部門的部分-*************---

                        if (Session["Done_Test"].ToString() == "1")
                        {
                            
                            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));


                            //開啟資料庫
                            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
                            MySqlConnection conn_act = new MySqlConnection(connection_act);
                            conn_act.Open();

                            //取得時間
                            DateTime dt = DateTime.Now; // 取得現在時間
                            String Now_Time = dt.ToString("yyyy-MM-dd HH:mm:ss"); // 轉成字串

                            //MySql語句1
                            string sqlQuery_act = "REPLACE INTO `spt_recipe_depo_time` (EQP_ID,Recipe_Name,Default_Value,Depo_Time_Value,Remark,Create_User,Create_Time,Update_User,Update_Time)" +
                                                  "VALUES (\"" + P9_Click_EQP_ID + "\",\"" + Session["Final_Recipe_Name"] + "\",\"" + Session["Final_Default_Value"] + "\",\"" + Session["Final_Value"] + "\",\"" + Session["Final_Remark"] + 
                                                  "\",\"" + user_name + "\",\"" + Now_Time + "\",\"" + user_name + "\",\"" + Now_Time + "\") ";
                            //執行
                            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();


                            //MySql語句2
                            sqlQuery_act = "REPLACE INTO `spt_recipe_depo_time_log` (EQP_ID,Recipe_Name,Default_Value,Depo_Time_Value,Remark,Update_User,Update_Time)" +
                                            "VALUES (\"" + P9_Click_EQP_ID + "\",\"" + Session["Final_Recipe_Name"] + "\",\"" + Session["Final_Default_Value"] + "\",\"" + Session["Final_Value"] + "\",\"" + Session["Final_Remark"] + "\",\"" + user_name + "\",\"" + Now_Time + "\")";
                            //執行
                            cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();
                            conn_act.Close();

                            //Response.Write(sqlQuery_act);

                            //--同步新增至第三頁調秒設定的Recipe--












                            //--同步新增至第三頁調秒設定的Recipe--

                            //清空session
                            ClearSession();

                            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            //HttpContext.Current.Response.Cookies["UpdateUserName"].Value = null;
                            //HttpContext.Current.Response.Cookies["UpdateDept"].Value = null;
                            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
                            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);

                            //重整網頁
                            //Response.Redirect("R2R_TargetLifeRangeSetting.aspx");
                        }
                    }
                    break;
                case "1":  //修改指令
                    {
                        //----**************要加入判斷部門的部分-*************---

                        if (Session["Final_Value"] != null && Session["Done_Test"].ToString() == "1")
                        {
                            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));

                            //開啟資料庫
                            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
                            MySqlConnection conn_act = new MySqlConnection(connection_act);
                            conn_act.Open();

                            //取得時間
                            DateTime dt = DateTime.Now; // 取得現在時間
                            String Now_Time = dt.ToString("yyyy-MM-dd HH:mm:ss"); // 轉成字串

                            //MySql語句1
                            string sqlQuery_act = "UPDATE `spt_recipe_depo_time` SET Default_Value = \"" + Session["Final_Default_Value"] + "\", Depo_Time_Value= \"" + Session["Final_Value"] + "\", Remark=\"" + Session["Final_Remark"] + "\" ,Update_User=\"" + user_name + "\",Update_Time = \"" + Now_Time +
                                                  "\" WHERE EQP_ID=\"" + P9_Click_EQP_ID + "\" AND Recipe_Name=\"" + Session["SelectRecipe"] + "\"";
                            //執行
                            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();

                            //MySql語句2
                            sqlQuery_act = "INSERT INTO `spt_recipe_depo_time_log` SET EQP_ID=\"" + P9_Click_EQP_ID + "\", Recipe_Name=\"" + Session["SelectRecipe"] + "\", Default_Value=\"" + Session["Final_Default_Value"] + "\" , Depo_Time_Value= \"" + Session["Final_Value"] + "\", Remark=\"" + Session["Final_Remark"] + "\" ,Update_User=\"" + user_name + "\",Update_Time = \"" + Now_Time + "\"";
                            //執行
                            cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();

                            conn_act.Close();

                            //Response.Write(sqlQuery_act);

                            //清空session
                            ClearSession();

                            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            //HttpContext.Current.Response.Cookies["UpdateUserName"].Value = null;
                            //HttpContext.Current.Response.Cookies["UpdateDept"].Value = null;
                            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
                            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);
                        }
                    }
                    break;
                case "2":  //刪除指令
                    {
                        //----**************要加入判斷部門的部分-*************---

                        if (Session["SelectRecipe"] != null)
                        {
                            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));

                            //開啟資料庫
                            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
                            MySqlConnection conn_act = new MySqlConnection(connection_act);
                            conn_act.Open();

                            //取得時間
                            DateTime dt = DateTime.Now; // 取得現在時間
                            String Now_Time = dt.ToString("yyyy-MM-dd HH:mm:ss"); // 轉成字串

                            //MySql語句1
                            string sqlQuery_act = "DELETE FROM `spt_recipe_depo_time` WHERE EQP_ID=\"" + P9_Click_EQP_ID + "\" AND Recipe_Name=\"" + Session["SelectRecipe"] + "\"";
                            //執行
                            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();


                            //MySql語句2
                            sqlQuery_act = "INSERT INTO `spt_recipe_depo_time_log` SET EQP_ID=\"" + P9_Click_EQP_ID + "\", Recipe_Name=\"" + Session["SelectRecipe"] + "\", Default_Value=\"" + Session["Final_Default_Value"] + "\" , Depo_Time_Value= \"" + Session["Final_Value"] + "\", Remark=\"刪除\" ,Update_User=\"" + user_name + "\",Update_Time = \"" + Now_Time + "\"";
                            //執行
                            cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                            cmd_act.ExecuteNonQuery();

                            conn_act.Close();

                            //Response.Write(sqlQuery_act);

                            //清空session
                            ClearSession();

                            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
                            //HttpContext.Current.Response.Cookies["UpdateUserName"].Value = null;
                            //HttpContext.Current.Response.Cookies["UpdateDept"].Value = null;
                            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
                            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);
                        }
                    }
                    break;
            }
        }


       


        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        //MySql查詢語句：查target_life欄位
        string sqlQuery = "SELECT Life_From,Life_To FROM `spt_target_life_range` WHERE EQP_ID='" + P9_Click_EQP_ID + "'";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset column_table中
        data.Fill(column_table);

        //------

        //MySql查詢語句：查資料
        sqlQuery = "SELECT * FROM `spt_recipe_depo_time` WHERE EQP_ID='" + P9_Click_EQP_ID + "'";

        //執行查詢
        cmd = new MySqlCommand(sqlQuery, conn);
        data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset data_table中
        data.Fill(data_table);

        conn.Close();
        
        
        //新增與其他指令檢視的表格不同
        if (Session["Act"] != null && Session["Done_Test"] != null && Session["Act"].ToString() == "0" && Session["Done_Test"].ToString() == "0")
        {
            Button button_add = (Button)FindControl("Button_Add");
            button_add.Text = "取消新增";


            //顯示表格
            Table Table1 = (Table)this.FindControl("Table1");         //找到元件

            //表格標頭
            TableRow row_head = new TableRow();

            for (int i = 0; i < data_table.Columns.Count-4; i++)
            {
                if (i == 3)
                {
                    for (int x = 0; x < column_table.Rows.Count; x++)
                    {
                        TableCell cell_head = new TableCell();
                        cell_head.Text = column_table.Rows[x][0] + "~" + column_table.Rows[x][1];
                        cell_head.Font.Size = 10;  //字型
                        cell_head.Font.Bold = true;  //字體粗體
                        cell_head.ForeColor = ColorTranslator.FromHtml("#3333CC");
                        cell_head.BackColor = ColorTranslator.FromHtml("#AAFFEE"); //設定背景顏色
                        row_head.Cells.Add(cell_head);
                    }
                }
                else
                {
                    TableCell cell_head = new TableCell();
                    cell_head.Text = data_table.Columns[i].ColumnName.ToString();
                    cell_head.Font.Size = 10;  //字型
                    cell_head.Font.Bold = true;  //字體粗體
                    cell_head.ForeColor = ColorTranslator.FromHtml("#3333CC");
                    cell_head.BackColor = ColorTranslator.FromHtml("#CCFFFF"); //設定背景顏色
                    row_head.Cells.Add(cell_head);
                }
            }

            //欄位修改
            TableCell cell_temp = new TableCell();
            cell_temp.Text = "動作";
            cell_temp.Font.Bold = true;  //字體粗體
            cell_temp.Font.Size = 10;  //字型
            cell_temp.ForeColor = Color.White;
            cell_temp.BackColor = ColorTranslator.FromHtml("#D2B48C"); //設定背景顏色
            row_head.Cells.Add(cell_temp);

            Table1.Rows.Add(row_head);


            //Data

            TableRow row = new TableRow();
            Select_Recipe_num = column_table.Rows.Count;
            for (int column_index = 0; column_index < data_table.Columns.Count - 5 + Select_Recipe_num; column_index++)
            {
                TableCell cell1 = new TableCell();

                if (column_index == 0)
                {
                    cell1.Text = P9_Click_EQP_ID;
                    row.Cells.Add(cell1);
                }
                else
                {
                    TextBox textbox = new TextBox();
                    textbox.ID = "TextBox_" + Convert.ToString(column_index);
                    textbox.Width = new Unit("80%");
                    textbox.Style["text-align"] = "center";
                    cell1.Controls.Add(textbox);
                    row.Cells.Add(cell1);
                }

            }


            //動作按鈕
            TableCell btnCell = new TableCell();
            Button btn = new Button();
            btn.Text = "新增";
            btn.ID = "Button_Add_OK";
            btn.BorderColor = ColorTranslator.FromHtml("#000000");
            btn.Click += new EventHandler(Button_Add_OK);
            btnCell.Controls.Add(btn);
            row.Cells.Add(btnCell);


            Table1.Rows.Add(row);
            

        }
        else
        {
            //顯示表格
            Table Table1 = (Table)this.FindControl("Table1");         //找到元件

            //表格標頭
            TableRow row_head = new TableRow();

            for (int i = 0; i < data_table.Columns.Count; i++)
            {
                if (i == 3)
                {
                    for (int x = 0; x < column_table.Rows.Count; x++)
                    {
                        TableCell cell_head = new TableCell();
                        cell_head.Text = column_table.Rows[x][0] + "~" + column_table.Rows[x][1];
                        cell_head.Font.Size = 9;  //字型
                        cell_head.Font.Bold = true;  //字體粗體
                        cell_head.ForeColor = ColorTranslator.FromHtml("#3333CC");
                        cell_head.BackColor = ColorTranslator.FromHtml("#AAFFEE"); //設定背景顏色

                        cell_head.Width = new Unit((45 / column_table.Rows.Count).ToString() + "%");

                        row_head.Cells.Add(cell_head);
                    }
                }
                else
                {
                    TableCell cell_head = new TableCell();
                    cell_head.Text = data_table.Columns[i].ColumnName.ToString();
                    cell_head.Font.Size = 9;  //字型
                    cell_head.Font.Bold = true;  //字體粗體
                    cell_head.ForeColor = ColorTranslator.FromHtml("#3333CC");
                    cell_head.BackColor = ColorTranslator.FromHtml("#CCFFFF"); //設定背景顏色

                    if (i == 6 | i == 8)
                        cell_head.Width = new Unit("10%");
                    else
                        cell_head.Width = new Unit("5%");


                    row_head.Cells.Add(cell_head);
                }
            }

            //欄位修改
            TableCell cell_temp = new TableCell();
            cell_temp.Width = new Unit("5%");
            cell_temp.Text = "調整";
            cell_temp.Font.Bold = true;  //字體粗體
            cell_temp.Font.Size = FontUnit.Small;  //字型
            cell_temp.ForeColor = Color.White;
            cell_temp.BackColor = ColorTranslator.FromHtml("#D2B48C"); //設定背景顏色
            row_head.Cells.Add(cell_temp);

            Table1.Rows.Add(row_head);


            //Data
            for (int row_index = 0; row_index < data_table.Rows.Count; row_index++)
            {
                TableRow row = new TableRow();
                for (int column_index = 0; column_index < data_table.Columns.Count; column_index++)
                {

                    if (column_index == 3)
                    {
                        string[] value_split = data_table.Rows[row_index][column_index].ToString().Split(',');  //要顯示的資料
                        Select_Recipe_num = column_table.Rows.Count;

                        for (int num = 0; num < Select_Recipe_num; num++)
                        {
                            TableCell cell1 = new TableCell();
                            cell1.Font.Size = 10;  //字型

                            //修改部分，要將文字改成Textbox
                            if (Session["Done_Test"] != null && Session["Done_Test"].ToString() == "0" && int.Parse(Session["select_index"].ToString()) == row_index && (column_index >= 3 & column_index < 3 + Select_Recipe_num))
                            {
                                TextBox textbox = new TextBox();
                                textbox.ID = "TextBox_Adjust_" + Convert.ToString(num);
                                textbox.Text = value_split[num];  //要顯示的資料
                                textbox.Width = new Unit("80%");
                                textbox.Style["text-align"] = "center";
                                cell1.Controls.Add(textbox);
                                row.Cells.Add(cell1);
                            }
                            else
                            {
                                cell1.Text = value_split[num];  //要顯示的資料
                                row.Cells.Add(cell1);
                            }
                        }

                    }
                    else
                    {
                        TableCell cell1 = new TableCell();

                        if (column_index == 6 | column_index == 8)
                            cell1.Font.Size = 8;  //字型
                        else
                            cell1.Font.Size = 9;  //字型

                        //修改部分，要將文字改成Textbox
                        if (Session["Done_Test"] != null && Session["Done_Test"].ToString() == "0" && int.Parse(Session["select_index"].ToString()) == row_index && (column_index == 2 | column_index == 4))
                        {
                            TextBox textbox = new TextBox();
                            textbox.ID = "TextBox_" + Convert.ToString(column_index);
                            textbox.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                            textbox.Width = new Unit("80%");
                            textbox.Style["text-align"] = "center";
                            cell1.Controls.Add(textbox);
                            row.Cells.Add(cell1);
                        }
                        else
                        {
                            cell1.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                            row.Cells.Add(cell1);
                        }

                    }

                }


                //調區間按鈕
                TableCell btnCell = new TableCell();

                Button btn = new Button();

                //先判斷有沒有null，使用&&
                if (Session["Done_Test"] != null && Session["Done_Test"].ToString() == "0" && int.Parse(Session["select_index"].ToString()) == row_index)
                {
                    btn.Text = "更新";
                }
                else
                {
                    btn.Text = "修改";
                }
                btn.BorderColor = ColorTranslator.FromHtml("#000000");
                btn.ID = "Button_Adjust_" + Convert.ToString(row_index);
                btn.Click += new EventHandler(Button_Adjust);
                btnCell.Controls.Add(btn);
                row.Cells.Add(btnCell);


                //刪除按鈕
                //btnCell = new TableCell();
                btn = new Button();
                btn.Text = "刪除";

                btn.ID = "Button_Delete_" + Convert.ToString(row_index);
                btn.Click += new EventHandler(Button_Delete);
                btn.Attributes.CssStyle.Add("margin-top", "10px");
                btn.BackColor = ColorTranslator.FromHtml("#ffa07a");
                btn.BorderColor = ColorTranslator.FromHtml("#ff0000");
                btn.Attributes.Add("onclick", "return confirm('是否確定要刪除?');");
                btnCell.Controls.Add(btn);
                row.Cells.Add(btnCell);


                Table1.Rows.Add(row);
            }
        }

    }

    protected void Button_1_event(object sender, EventArgs e)
    {
        P9_Click_EQP_ID = Fix_EQP_ID[0];
        ClearSession();
        Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);
    }

    protected void Button_2_event(object sender, EventArgs e)
    {
        P9_Click_EQP_ID = Fix_EQP_ID[1];
        ClearSession();
        Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);
    }

    protected void Button_3_event(object sender, EventArgs e)
    {
        P9_Click_EQP_ID = Fix_EQP_ID[2];
        ClearSession();
        Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);
    }

    protected void Button_4_event(object sender, EventArgs e)
    {
        P9_Click_EQP_ID = Fix_EQP_ID[3];
        ClearSession();
        Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);
    }

    protected void Button_5_event(object sender, EventArgs e)
    {
        P9_Click_EQP_ID = Fix_EQP_ID[4];
        ClearSession();
        Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);
    }

    protected void Button_6_event(object sender, EventArgs e)
    {
        P9_Click_EQP_ID = Fix_EQP_ID[5];
        ClearSession();
        Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);
    }

    //修改按鈕
    protected void Button_Adjust(object sender, EventArgs e)
    {
        string Button_ID = ((Button)sender).ID;
        int select_index = int.Parse(Button_ID.ToString().Split('_')[2]);

        Button button_now = (Button)FindControl(Button_ID);

        Session["Act"] = 1;
        Session["select_index"] = select_index;
        Session["Done_Test"] = 0;

        if (button_now.Text == "更新")
        {
            string Final_Value = "";

            for (int num = 0; num < Select_Recipe_num; num++)
            {
                string TextBox_ID = "TextBox_Adjust_" + num.ToString();
                TextBox TextBox_Adjust = (TextBox)FindControl(TextBox_ID);

                if (num == 0)
                {
                    Final_Value = TextBox_Adjust.Text;
                }
                else
                {
                    Final_Value = Final_Value + "," + TextBox_Adjust.Text;
                }
            }

            TextBox TextBox_Default_Value = (TextBox)FindControl("TextBox_2");
            TextBox TextBox_Remark = (TextBox)FindControl("TextBox_4");
            Session["Final_Default_Value"] = TextBox_Default_Value.Text;
            Session["Final_Remark"] = TextBox_Remark.Text;
            Session["Act"] = 1;
            Session["Final_Value"] = Final_Value;
            Session["SelectRecipe"] = data_table.Rows[select_index][1].ToString();
            Session["Done_Test"] = 1;

            //UAC認證
            Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_RecipeSetting&P9_Click_EQP_ID=" + P9_Click_EQP_ID);
        }
        
        Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);

    }

    //刪除按鈕
    protected void Button_Delete(object sender, EventArgs e)
    {
        string Button_ID = ((Button)sender).ID;
        int select_index = int.Parse(Button_ID.ToString().Split('_')[2]);

        Session["Act"] = 2;
        Session["SelectRecipe"] = data_table.Rows[select_index][1].ToString();
        Session["Final_Default_Value"] = data_table.Rows[select_index][2].ToString();
        Session["Final_Value"] = data_table.Rows[select_index][3].ToString();

        //UAC認證
        Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_RecipeSetting&P9_Click_EQP_ID=" + P9_Click_EQP_ID);
    
    }

    //顯示新增畫面
    protected void Button_Add_event(object sender, EventArgs e)
    {
        Button button_now = (Button)FindControl(((Button)sender).ID);

        if (button_now.Text == "新增")
        {
            Session["Act"] = 0;
            Session["Done_Test"] = "0";

            Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);
        }
        else
        {
            ClearSession();
            Response.Redirect("R2R_RecipeSetting.aspx?P9_Click_EQP_ID=" + P9_Click_EQP_ID);
        }
    }

    //確定新增資料
    protected void Button_Add_OK(object sender, EventArgs e)
    {
        string Final_Value = "";

        for (int num = 3; num < Select_Recipe_num+3; num++)
        {
            string TextBox_ID = "TextBox_" + num.ToString();
            TextBox TextBox_Adjust = (TextBox)FindControl(TextBox_ID);

            if (num == 3)
            {
                Final_Value = TextBox_Adjust.Text;
            }
            else
            {
                Final_Value = Final_Value + "," + TextBox_Adjust.Text;
            }
        }
        TextBox TextBox_Recipe_Name = (TextBox)FindControl("TextBox_1");
        TextBox TextBox_Default_Value = (TextBox)FindControl("TextBox_2");
        TextBox TextBox_Remark = (TextBox)FindControl("TextBox_" + (Select_Recipe_num + 3).ToString());
        Session["Final_Recipe_Name"] = TextBox_Recipe_Name.Text;
        Session["Final_Default_Value"] = TextBox_Default_Value.Text;
        Session["Final_Remark"] = TextBox_Remark.Text;
        Session["Final_Value"] = Final_Value;
        Session["Act"] = 0;
        Session["Done_Test"] = "1";

        //UAC認證
        Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_RecipeSetting&P9_Click_EQP_ID=" + P9_Click_EQP_ID);
    }

    private void ClearSession()
    {
        Session["Act"] = "";
        Session["Final_Value"] = "";
        Session["SelectRecipe"] = "";
        Session["Done_Test"] = "";
        Session["Final_Remark"] = "";
        Session["Final_Default_Value"] = "";
    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {

    }


}

