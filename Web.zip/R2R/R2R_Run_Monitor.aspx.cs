﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Drawing;
using System.Text;


public partial class Run_Monitor : Page
{

    DataTable dt = new DataTable();
    ArrayList Q_EQP_ID = new ArrayList();
    ArrayList Q_Product = new ArrayList();
    ArrayList Q_PEP = new ArrayList();  //PEP1:0  PEP3:1  AITO:2  PITO:3
    ArrayList Q_LatestTime = new ArrayList();
    ArrayList Q_LatestTime_Light = new ArrayList();

    //最後要著色的紀錄，改良同一機台出現兩筆紀錄時，顏色應個別對應
    ArrayList Draw_EQP_ID = new ArrayList();
    ArrayList Draw_Product = new ArrayList();
    ArrayList Draw_PEP = new ArrayList();
    ArrayList Draw_LatestTime = new ArrayList();
    ArrayList Draw_LatestTime_Light = new ArrayList();

    String[] DB_Name = { "m1_spt_rs", "m2_spt_rs", "aito_spt_rs", "pito_spt_rs" };
    String[] Fix_EQP_ID = { "AFSPT100", "AFSPT200", "AFSPT300", "AFSPT400", "AFSPT500", "AFSPT600" };
    String[] Fix_Product = { "M238HVN01", "T320HVN05", "T320HVN06", "T320HVN07", "T320XVN04", "T460HVN09", "T550QVN05", "T550QVN06", "T550QVR07", "T550QVR10", "T550QVR11", "T550QVN10.0" };


    protected void Page_Load(object sender, EventArgs e)
    {
        /*
        Response.Write(Request.QueryString["Click_Product"] + " <p> ");
        Response.Write(Request.QueryString["Click_EQP_ID"] + " <p> ");
        Response.Write(Request.QueryString["Click_PEP"] + " <p> ");
        */
        //Response.Write(HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["8AR2RUserName"].Value, Encoding.GetEncoding("big5")));

        System.DateTime startTime = DateTime.Now;


        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();


        /*---查詢與產生現況表格---*/
        /*---直接在網頁上抓最新紀錄-->慢!!
        for (int DB_index = 0; DB_index < DB_Name.Length; DB_index++)
        {
            DataTable dt_LatestTime = new DataTable();

            //MySql查詢語句
            //String sqlQuery = "SELECT STARTTIME,LIGHT FROM `" + DB_Name[DB_index] + "`  WHERE Product=\"" + Fix_Product[y] + "\" and EQP_ID=\"" + Fix_EQP_ID[x] + "\" ORDER BY STARTTIME DESC LIMIT 1;";
            //String sqlQuery = "SELECT max(STARTTIME),LIGHT,Product,EQP_ID FROM `" + DB_Name[DB_index] + "` group by Project_ID;";
            String sqlQuery = "SELECT STARTTIME,LIGHT,Product,EQP_ID FROM `" + DB_Name[DB_index] + "` A,(SELECT Project_ID,max(STARTTIME) max_time FROM `" + DB_Name[DB_index] + "` GROUP BY Project_ID) B WHERE A.STARTTIME = B.max_time AND A.Project_ID = B.Project_ID";


            //執行查詢
            MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
            MySqlDataAdapter data = new MySqlDataAdapter();
            data.SelectCommand = cmd;

            //將查詢結果注入到dataset dt_temp中
            data.Fill(dt_LatestTime);

            for (int x = 0; x < dt_LatestTime.Rows.Count; x++)
            {
                String LatestTime = Convert.ToDateTime(dt_LatestTime.Rows[x][dt_LatestTime.Columns[0]]).ToString("yyyy-MM-dd HH:mm:ss");
                String LatestRecord_Light = dt_LatestTime.Rows[x][dt_LatestTime.Columns[1]].ToString();
                String Temp_Product = dt_LatestTime.Rows[x][dt_LatestTime.Columns[2]].ToString();
                String Temp_EQP_ID = dt_LatestTime.Rows[x][dt_LatestTime.Columns[3]].ToString();


                Q_LatestTime.Add(LatestTime);
                Q_LatestTime_Light.Add(LatestRecord_Light);
                Q_Product.Add(Temp_Product);
                Q_EQP_ID.Add(Temp_EQP_ID);
                Q_PEP.Add(DB_index);
            }
        }---*/

        //---從資料庫抓最新紀錄---
        DataTable dt_LatestTime = new DataTable();

        //MySql查詢語句
        String sqlQuery = "SELECT * FROM `spt_rs_latest_record_time`;";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset dt_temp中
        data.Fill(dt_LatestTime);

        for (int x = 0; x < dt_LatestTime.Rows.Count; x++)
        {
            String Temp_PEP = dt_LatestTime.Rows[x][dt_LatestTime.Columns[0]].ToString();
            String Temp_EQP_ID = dt_LatestTime.Rows[x][dt_LatestTime.Columns[1]].ToString();
            String Temp_Product = dt_LatestTime.Rows[x][dt_LatestTime.Columns[2]].ToString();
            String LatestRecord_Light = dt_LatestTime.Rows[x][dt_LatestTime.Columns[3]].ToString();
            String LatestTime = Convert.ToDateTime(dt_LatestTime.Rows[x][dt_LatestTime.Columns[4]]).ToString("yyyy-MM-dd HH:mm:ss");


            Q_LatestTime.Add(LatestTime);
            Q_LatestTime_Light.Add(LatestRecord_Light);
            Q_Product.Add(Temp_Product);
            Q_EQP_ID.Add(Temp_EQP_ID);

            if (Temp_PEP == "PEP1")
                Q_PEP.Add(0);
            else if (Temp_PEP == "PEP3")
                Q_PEP.Add(1);
            else if (Temp_PEP == "AITO")
                Q_PEP.Add(2);
            else if (Temp_PEP == "PITO")
                Q_PEP.Add(3);
        }


        //查詢每個機台最新的紀錄
        for (int EQP_index = 0; EQP_index < Fix_EQP_ID.Length; EQP_index++)
        {
            int TempMaxRecord_index = -1;

            //先找出某機台的最大時間
            for (int x = 0; x < Q_EQP_ID.Count; x++)
            {
                if (Q_EQP_ID[x].ToString() == Fix_EQP_ID[EQP_index].ToString())
                {
                    if (TempMaxRecord_index == -1)
                    {
                        TempMaxRecord_index = x;
                    }
                    else
                    {
                        if (Convert.ToDateTime(Q_LatestTime[TempMaxRecord_index]) < Convert.ToDateTime(Q_LatestTime[x]))
                        {
                            TempMaxRecord_index = x;
                        }
                    }
                }
            }

            //利用最大時間找出符合的紀錄(理論上一筆，但有時候出現兩筆)
            for (int x = 0; x < Q_EQP_ID.Count; x++)
            {
                if (Q_EQP_ID[x].ToString() == Fix_EQP_ID[EQP_index].ToString())
                {
                    if (Convert.ToDateTime(Q_LatestTime[TempMaxRecord_index]) == Convert.ToDateTime(Q_LatestTime[x]))
                    {
                        Draw_EQP_ID.Add(Q_EQP_ID[x].ToString());
                        Draw_Product.Add(Q_Product[x].ToString());
                        Draw_PEP.Add(Q_PEP[x].ToString());
                        Draw_LatestTime.Add(Q_LatestTime[x].ToString());
                        Draw_LatestTime_Light.Add(Q_LatestTime_Light[x].ToString());
                    }
                }
            }
        }


        System.DateTime BlockTime_1 = DateTime.Now;
        long timeStamp = (long)(BlockTime_1 - startTime).TotalMilliseconds; // 相差毫秒數
        System.Console.WriteLine(timeStamp);

        conn.Close();


        //顯示表格
        Table Table1 = (Table)this.FindControl("Table1");         //找到元件
        Table1.BorderStyle = BorderStyle.Solid;
        Table1.BorderWidth = 2;


        //表格標頭-第一列
        TableRow row_head = new TableRow();
        for (int i = 0; i < 2; i++)
        {
            TableCell cell_head = new TableCell();

            if (i == 0)
            {
                cell_head.Text = "Product";
            }
            else if (i == 1)
            {
                cell_head.Text = "EQP_ID";
            }
            cell_head.BorderStyle = BorderStyle.Solid;
            cell_head.BorderWidth = 1;
            cell_head.BorderColor = System.Drawing.Color.Black;
            cell_head.Font.Bold = true;  //字體粗體
            cell_head.Font.Size = FontUnit.XLarge;  //大字型
            cell_head.BackColor = ColorTranslator.FromHtml("#D2B48C"); //設定背景顏色
            cell_head.HorizontalAlign = HorizontalAlign.Center;
            cell_head.Height = new Unit(Convert.ToInt16(cell_head.Height.Value) + 40, UnitType.Pixel);  //加大原有高度
            //cell_head.Width = new Unit(Convert.ToInt16(cell_head.Width.Value) + 100, UnitType.Pixel);  //加大原有寬度
            row_head.Cells.Add(cell_head);

        }
        Table1.Rows.Add(row_head);
        Table1.Rows[0].Cells[1].ColumnSpan = 12;
        Table1.Rows[0].Cells[0].RowSpan = 3;


        //表格標頭-第二列
        row_head = new TableRow();
        for (int i = 0; i < 6; i++)
        {
            TableCell cell_head = new TableCell();

            cell_head.Text = Convert.ToString(Fix_EQP_ID[i]);
            cell_head.BorderStyle = BorderStyle.Solid;
            cell_head.BorderWidth = 1;
            cell_head.BorderColor = System.Drawing.Color.Black;
            cell_head.Font.Bold = true;  //字體粗體
            cell_head.Font.Size = FontUnit.Larger;  //大字型
            cell_head.BackColor = ColorTranslator.FromHtml("#87CECB"); //設定背景顏色
            cell_head.HorizontalAlign = HorizontalAlign.Center;
            cell_head.Height = new Unit(Convert.ToInt16(cell_head.Height.Value) + 40, UnitType.Pixel);  //加大原有高度
            //cell_head.Width = new Unit(Convert.ToInt16(cell_head.Width.Value) + 100, UnitType.Pixel);  //加大原有寬度
            row_head.Cells.Add(cell_head);

        }
        Table1.Rows.Add(row_head);
        for (int i = 0; i < 6; i++)
        {
            Table1.Rows[1].Cells[i].ColumnSpan = 2;
        }

        //表格標頭-第三列
        row_head = new TableRow();
        for (int i = 0; i < 6; i++)
        {

            if (i < 4)
            {
                TableCell cell_head = new TableCell();
                cell_head.Text = "PEP1";
                cell_head.BorderStyle = BorderStyle.Solid;
                cell_head.BorderWidth = 1;
                cell_head.BorderColor = System.Drawing.Color.Black;
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.BackColor = ColorTranslator.FromHtml("#AFEEEE"); //設定背景顏色
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.Height = new Unit(Convert.ToInt16(cell_head.Height.Value) + 40, UnitType.Pixel);  //加大原有高度
                //cell_head.Width = new Unit(Convert.ToInt16(cell_head.Width.Value) + 100, UnitType.Pixel);  //加大原有寬度
                row_head.Cells.Add(cell_head);


                cell_head = new TableCell();
                cell_head.Text = "PEP3";
                cell_head.BorderStyle = BorderStyle.Solid;
                cell_head.BorderWidth = 1;
                cell_head.BorderColor = System.Drawing.Color.Black;
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.BackColor = ColorTranslator.FromHtml("#AFEEEE"); //設定背景顏色
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.Height = new Unit(Convert.ToInt16(cell_head.Height.Value) + 40, UnitType.Pixel);  //加大原有高度
                //cell_head.Width = new Unit(Convert.ToInt16(cell_head.Width.Value) + 100, UnitType.Pixel);  //加大原有寬度
                row_head.Cells.Add(cell_head);
            }
            else //5、6
            {
                TableCell cell_head = new TableCell();
                cell_head.Text = "AITO";
                cell_head.BorderStyle = BorderStyle.Solid;
                cell_head.BorderWidth = 1;
                cell_head.BorderColor = System.Drawing.Color.Black;
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.BackColor = ColorTranslator.FromHtml("#AFEEEE"); //設定背景顏色
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.Height = new Unit(Convert.ToInt16(cell_head.Height.Value) + 40, UnitType.Pixel);  //加大原有高度
                //cell_head.Width = new Unit(Convert.ToInt16(cell_head.Width.Value) + 100, UnitType.Pixel);  //加大原有寬度
                row_head.Cells.Add(cell_head);


                cell_head = new TableCell();
                cell_head.Text = "PITO";
                cell_head.BorderStyle = BorderStyle.Solid;
                cell_head.BorderWidth = 1;
                cell_head.BorderColor = System.Drawing.Color.Black;
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.BackColor = ColorTranslator.FromHtml("#AFEEEE"); //設定背景顏色
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.Height = new Unit(Convert.ToInt16(cell_head.Height.Value) + 40, UnitType.Pixel);  //加大原有高度
                //cell_head.Width = new Unit(Convert.ToInt16(cell_head.Width.Value) + 100, UnitType.Pixel);  //加大原有寬度
                row_head.Cells.Add(cell_head);
            }
        }
        Table1.Rows.Add(row_head);

        //Data
        for (int j = 0; j < 12; j++)
        {
            TableRow row = new TableRow();

            //產品名稱
            TableCell cell1 = new TableCell();
            cell1.Text = Convert.ToString(Fix_Product[j]);
            cell1.Font.Bold = true;  //字體粗體
            //cell1.Font.Size = FontUnit.Large;  //大字型
            //cell1.ForeColor = System.Drawing.Color.Blue; //設定文字顏色
            cell1.ForeColor = ColorTranslator.FromHtml("#643200");  //設定文字顏色
            cell1.BackColor = ColorTranslator.FromHtml("#FFFFE1"); //設定背景顏色
            cell1.HorizontalAlign = HorizontalAlign.Center;
            cell1.BorderStyle = BorderStyle.Solid;
            cell1.BorderWidth = 1;
            cell1.BorderColor = System.Drawing.Color.Black;
            cell1.Height = new Unit(Convert.ToInt16(cell1.Height.Value) + 60, UnitType.Pixel);  //加大原有高度
            cell1.Width = new Unit(Convert.ToInt16(cell1.Width.Value) + 150, UnitType.Pixel);  //加大原有寬度
            row.Cells.Add(cell1);

            //先初始化每一格Data都是.
            for (int k = 0; k < 12; k++)
            {
                cell1 = new TableCell();

                int check_index = Convert.ToUInt16(k / 2);
                bool FindTest = false;

                //檢視每一筆查到的資料
                for (int m = 0; m < Q_EQP_ID.Count; m++)
                {
                    //
                    if (Convert.ToString(Q_EQP_ID[m]) == Convert.ToString(Fix_EQP_ID[check_index]) & Convert.ToString(Q_Product[m]) == Convert.ToString(Fix_Product[j]))
                    {
                        //檢查哪一個PEP
                        if (  ((k < 8) & ((k + 1) % 2 == 1 & Convert.ToInt16(Q_PEP[m]) == 0) | ((k + 1) % 2 == 0 & Convert.ToInt16(Q_PEP[m]) == 1))  |  ((k>=8) & ((k + 1) % 2 == 1 & Convert.ToInt16(Q_PEP[m]) == 2) | ((k + 1) % 2 == 0 & Convert.ToInt16(Q_PEP[m]) == 3))    )
                        {
                                cell1.Text = Convert.ToString(Q_LatestTime[m]);
                                cell1.Font.Size = 10;
                                FindTest = true;
                                cell1.BorderWidth = 1;
                                cell1.BorderColor = System.Drawing.Color.Black;
                                
                                //最新紀錄用不同顏色處理
                                for (int n = 0; n < Draw_EQP_ID.Count; n++)
                                {
                                    if ((Draw_EQP_ID[n].ToString() == Q_EQP_ID[m].ToString()) & (Draw_Product[n].ToString() == Q_Product[m].ToString()) & (Draw_PEP[n].ToString() == Q_PEP[m].ToString()) & (Draw_LatestTime[n].ToString() == Q_LatestTime[m].ToString()) )
                                    {
                                        cell1.BorderWidth = 2;
                                        cell1.BorderColor = ColorTranslator.FromHtml("#003388");
                                        //設定背景顏色
                                        if (Draw_LatestTime_Light[n].ToString() == "GREEN")
                                        {
                                            cell1.BackColor = ColorTranslator.FromHtml("#AAFFAA");
                                        }
                                        else if (Draw_LatestTime_Light[n].ToString() == "YELLOW")
                                        {
                                            cell1.BackColor = ColorTranslator.FromHtml("#FFFFAA");
                                        }
                                        else if (Draw_LatestTime_Light[n].ToString() == "RED")
                                        {
                                            cell1.BackColor = ColorTranslator.FromHtml("#FFAAAA");
                                        }
                                        else if (Draw_LatestTime_Light[n].ToString() == "BLUE")
                                        {
                                            cell1.BackColor = ColorTranslator.FromHtml("#AAFFFF");
                                        }
                                        break;
                                    }
                                }

                                break;
                        }

                    }

                }

                if (!FindTest)
                {
                    cell1.Text = ".";
                    cell1.Font.Size = 0;
                    cell1.BorderColor = ColorTranslator.FromHtml("#BEBEBE");
                    cell1.BorderWidth = 1;
                }


                cell1.HorizontalAlign = HorizontalAlign.Center;
                cell1.BorderStyle = BorderStyle.Solid;
                cell1.Width = new Unit(Convert.ToInt16(cell1.Width.Value) + 150, UnitType.Pixel);  //加大原有寬度
                row.Cells.Add(cell1);
            }
            //產生表格
            Table1.Rows.Add(row);


            for (int k = 1; k < 13; k++)
            {
                if (Table1.Rows[j + 3].Cells[k].Text != ".")
                {
                    String Click_EQP_ID = "";
                    String Click_PEP = "";
                    String Click_EndDate = Table1.Rows[j + 3].Cells[k].Text.Split(' ')[0];
                    String Click_StartDate = DateTime.Parse(Click_EndDate).AddDays(-5).ToString("yyyy-MM-dd");

                    if (k < 3)
                    {
                        Click_EQP_ID = Fix_EQP_ID[0];
                    }
                    else
                    {
                        Click_EQP_ID = Fix_EQP_ID[(k - 1) / 2];
                    }

                    if (k < 9)
                    {
                        if (k % 2 == 1)
                        {
                            Click_PEP = "PEP1";
                        }
                        else
                        {
                            Click_PEP = "PEP3";
                        }
                    }
                    else
                    {
                        if (k % 2 == 1)
                        {
                            Click_PEP = "AITO";
                        }
                        else
                        {
                            Click_PEP = "PITO";
                        }
                    }


                    Table1.Rows[j + 3].Cells[k].Attributes.Add("style", "cursor:pointer;");
                    Table1.Rows[j + 3].Cells[k].Attributes.Add("onclick", "location='?Click_Product=" + Table1.Rows[j + 3].Cells[0].Text + "&Click_EQP_ID=" + Click_EQP_ID + "&Click_PEP=" + Click_PEP + "&Click_StartDate=" + Click_StartDate + "&Click_EndDate=" + Click_EndDate + "'"); //存變數至網址並傳到下一頁
                }
            }
        }//DATA
    }


    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        ArrayList Real_Y_B = new ArrayList();
        ArrayList Predict_PLS_B = new ArrayList();
        ArrayList Predict_XGB_B = new ArrayList();
        ArrayList SPC_Values = new ArrayList();
        ArrayList STARTTIME = new ArrayList();
        ArrayList LIGHT = new ArrayList();

        /*
        Response.Write(Request.QueryString["Click_Product"] + " <p> ");
        Response.Write(Request.QueryString["Click_EQP_ID"] + " <p> ");
        Response.Write(Request.QueryString["Click_PEP"] + " <p> ");
        */

        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        /*---查詢產生按下去的raw data---*/
        String Q_DB_Name = "";
        if (Request.QueryString["Click_Product"] != null)
        {
            this.End_Date.Value = Request.QueryString["Click_EndDate"];
            String PassQ_End_Date = DateTime.Parse(this.End_Date.Value).AddDays(1).ToString("yyyy-MM-dd");
            this.Start_Date.Value = Request.QueryString["Click_StartDate"];

            switch (Request.QueryString["Click_PEP"])
            {
                case "PEP1":
                    Q_DB_Name = DB_Name[0];
                    break;
                case "PEP3":
                    Q_DB_Name = DB_Name[1];
                    break;
                case "AITO":
                    Q_DB_Name = DB_Name[2];
                    break;
                case "PITO":
                    Q_DB_Name = DB_Name[3];
                    break;
            }


            //MySql查詢語句
            string sqlQuery = "SELECT * FROM ( SELECT * FROM " + Q_DB_Name + " WHERE EQP_ID=\"" + Request.QueryString["Click_EQP_ID"] + "\" and  Product=\"" + Request.QueryString["Click_Product"] + "\" and (STARTTIME BETWEEN \"" + this.Start_Date.Value + "\" and \"" + PassQ_End_Date + "\") order by STARTTIME DESC LIMIT 1000 ) as A order by STARTTIME";
            //Response.Write(sqlQuery);

            //執行查詢
            MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
            MySqlDataAdapter data = new MySqlDataAdapter();
            data.SelectCommand = cmd;

            //將查詢結果注入到dataset Ds中

            data.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                //補上Index
                dt.Columns.Add("Index", typeof(int)).SetOrdinal(0);
                //補上數字
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dt.Rows[i][0] = i.ToString();
                }


                GridView GridView1 = (GridView)this.FindControl("GridView1");
                GridView GridView2 = (GridView)this.FindControl("GridView2");
                GridView1.Attributes.Add("style", "table-layout:fixed"); //固定標頭欄位
                GridView2.Attributes.Add("style", "table-layout:fixed ");

                GridView1.DataSource = dt;
                GridView1.DataBind();
                GridView2.DataSource = dt;
                GridView2.DataBind();
                GridView2.HeaderRow.Visible = false;
            }




            //傳值到前端
            //string[] p = new string[] { "10.5", "12.8", "23" };

            /*
            ArrayList p = new ArrayList();
            p.Add("11");
            p.Add("17.8");
            p.Add("13.56");

            String[] obj1 = (String[])p.ToArray(typeof(string));


            //this.Page.RegisterClientScriptBlock("array", string.Format("<script>var p=\"{0}\";</script>", string.Join(",", p)));
            this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "xx", string.Format("<script>var k=\"{0}\";</script>", string.Join(",", obj1)));
            */


            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (Convert.ToString(dt.Rows[i][8]) == "")
                {
                    Real_Y_B.Add("");
                }
                else
                {
                    Real_Y_B.Add(Convert.ToString(dt.Rows[i][8]));
                }


                if (Convert.ToInt16(dt.Rows[i][9]) == -9999)
                {
                    Predict_PLS_B.Add("");
                }
                else
                {
                    Predict_PLS_B.Add(Convert.ToString(dt.Rows[i][9]));
                }


                if (Convert.ToInt16(dt.Rows[i][10]) == -9999)
                {
                    Predict_XGB_B.Add("");
                }
                else
                {
                    Predict_XGB_B.Add(Convert.ToString(dt.Rows[i][10]));
                }

                STARTTIME.Add(Convert.ToString(dt.Rows[i][11]));
                LIGHT.Add(Convert.ToString(dt.Rows[i][6]));
            }

            //讀取管制線
            //MySql查詢語句
            sqlQuery = "SELECT USL,UCL,CL,LCL,LSL FROM `spt_rs_spec` WHERE Product=\"" + Request.QueryString["Click_Product"] + "\" and PEP=\"" + Request.QueryString["Click_PEP"] + "\" and Graph_Type=\"X\"";

            //執行查詢
            cmd = new MySqlCommand(sqlQuery, conn);
            data = new MySqlDataAdapter();
            data.SelectCommand = cmd;

            //將查詢結果注入到DataTable中
            DataTable dt_SPC = new DataTable();
            data.Fill(dt_SPC);


            for (int i = 0; i < dt_SPC.Columns.Count; i++)
            {
                SPC_Values.Add(dt_SPC.Rows[0][i].ToString());
            }

        }


        conn.Close();



        String[] Pass_Real_Y_B = (String[])Real_Y_B.ToArray(typeof(string));
        String[] Pass_Predict_PLS_B = (String[])Predict_PLS_B.ToArray(typeof(string));
        String[] Pass_Predict_XGB_B = (String[])Predict_XGB_B.ToArray(typeof(string));
        String[] Pass_SPC_Values = (String[])SPC_Values.ToArray(typeof(string));
        String[] Pass_STARTTIME = (String[])STARTTIME.ToArray(typeof(string));
        String[] Pass_LIGHT = (String[])LIGHT.ToArray(typeof(string));

        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x1", string.Format("<script>var Get_Real_Y=\"{0}\";</script>", string.Join(",", Pass_Real_Y_B)));
        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x2", string.Format("<script>var Get_Predict_PLS=\"{0}\";</script>", string.Join(",", Pass_Predict_PLS_B)));
        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x3", string.Format("<script>var Get_Predict_XGB=\"{0}\";</script>", string.Join(",", Pass_Predict_XGB_B)));
        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x4", string.Format("<script>var Get_SPC_Values=\"{0}\";</script>", string.Join(",", Pass_SPC_Values)));
        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x5", string.Format("<script>var Get_STARTTIME=\"{0}\";</script>", string.Join(",", Pass_STARTTIME)));
        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x6", string.Format("<script>var Get_LIGHT=\"{0}\";</script>", string.Join(",", Pass_LIGHT)));

        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x7", string.Format("<script>var Get_Click_Name=\"{0}\";</script>", Request.QueryString["Click_EQP_ID"] + "/" + Request.QueryString["Click_Product"] + "/" + Request.QueryString["Click_PEP"]));
    }


    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Visible = false;
        }


        for (int i = 0; i < e.Row.Controls.Count; i++)
        {
            if (i == 11 | i == 12)
            {
                e.Row.Cells[i].Width = 230;
            }
            else if (i == 0)
            {
                e.Row.Cells[i].Width = 60;
            }
            else
            {
                e.Row.Cells[i].Width = 100;
            }
            e.Row.Cells[i].Attributes.Add("style", "word-break :break-all ; word-wrap:break-word");
        }


        //更改背景顏色、框大小、文字大小與置中
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.BackColor = ColorTranslator.FromHtml("#D2B48C");
            e.Row.Height = 40;
            e.Row.HorizontalAlign = HorizontalAlign.Center;

            //e.Row.CssClass = "GridView_Style";


            for (int i = 0; i < e.Row.Controls.Count; i++)
            {
                e.Row.Cells[i].BorderWidth = 1;
                e.Row.Cells[i].BorderColor = System.Drawing.Color.Black;
                e.Row.Cells[i].BorderStyle = BorderStyle.Solid;
            }


            /*
            //If Salary is less than 10000 than set the row Background Color to Cyan  
            if (e.Row.Cells[5].Text == "LIGHT")
            {
                e.Row.Cells[5].BackColor = ColorTranslator.FromHtml("#87CECB"); //設定背景顏色
                //e.Row.Cells[0].Height = 60;
                //e.Row.Cells[0].Width = 60;
                //e.Row.Cells[0].Font.Size = 40;
                e.Row.Cells[5].HorizontalAlign = HorizontalAlign.Center;
            }
            */
        }


    }


    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridView GridView1 = (GridView)this.FindControl("GridView1");
        Response.Write("   QQ");

        //選取index 
        Response.Write(GridView1.SelectedIndex);
    }


    protected void GridView2_RowDataBound(object sender, GridViewRowEventArgs e)
    {

        for (int i = 0; i < e.Row.Controls.Count; i++)
        {
            if (i == 11 | i == 12)
            {
                e.Row.Cells[i].Width = 230;
            }
            else if (i == 0)
            {
                e.Row.Cells[i].Width = 60;
            }
            else
            {
                e.Row.Cells[i].Width = 100;
            }

            e.Row.Cells[i].Attributes.Add("style", "word-break :break-all ; word-wrap:break-word");
        }


        //更改背景顏色、框大小、文字大小與置中
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Height = 35;
            e.Row.HorizontalAlign = HorizontalAlign.Center;
            e.Row.BorderWidth = 1;
            e.Row.BorderColor = System.Drawing.Color.Black;

            for (int i = 0; i < e.Row.Controls.Count; i++)
            {
                e.Row.Cells[i].BorderWidth = 1;
                e.Row.Cells[i].BorderColor = System.Drawing.Color.Black;
                e.Row.Cells[i].BorderStyle = BorderStyle.Solid;
            }

            //設定背景顏色
            if (e.Row.Cells[6].Text == "GREEN")
            {
                e.Row.Cells[6].BackColor = ColorTranslator.FromHtml("#AAFFAA");
            }
            else if (e.Row.Cells[6].Text == "YELLOW")
            {
                e.Row.Cells[6].BackColor = ColorTranslator.FromHtml("#FFFFAA");
            }
            else if (e.Row.Cells[6].Text == "RED")
            {
                e.Row.Cells[6].BackColor = ColorTranslator.FromHtml("#FFAAAA");
            }
            else if (e.Row.Cells[6].Text == "BLUE")
            {
                e.Row.Cells[6].BackColor = ColorTranslator.FromHtml("#AAFFFF");
            }

        }

    }


    protected void Button_Query_Click(object sender, EventArgs e)
    {
        /*
        Response.Write(this.Start_Date.Value + " <p> ");
        Response.Write(this.End_Date.Value + " <p> ");
        */

        string url;
        url = System.IO.Path.GetFileName(Request.PhysicalPath) + "?Click_Product=" + Request.QueryString["Click_Product"] + "&Click_EQP_ID=" + Request.QueryString["Click_EQP_ID"] + "&Click_PEP=" + Request.QueryString["Click_PEP"] + "&Click_StartDate=" + this.Start_Date.Value + "&Click_EndDate=" + this.End_Date.Value;
        Response.Redirect(url);

    }


}

