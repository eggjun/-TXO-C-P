﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Drawing;
using System.Text;
using Oracle.ManagedDataAccess.Client;

public partial class TuneDepoTime : System.Web.UI.Page
{
    //DataTable column_table = new DataTable();
    DataTable data_table = new DataTable();  //調秒資料
    DataTable SVM_table = new DataTable();  //按鈕顏色燈號

    //尋找Target Life用
    DataTable TGL_table = new DataTable();  //抓Target Life值
    DataTable Python_table = new DataTable();  //抓Python更新時間
    //DataTable dt_LatestTime = new DataTable();  //抓EQP最新紀錄時間
    DataTable TGL_Range_table = new DataTable();  //對應EQP抓TGL區間
    DataTable DepoTime_table = new DataTable();   //對應EQP與TGL的DepoTime值
    String[] TB_Name = { "m1_spt_rs", "m2_spt_rs", "aito_spt_rs", "pito_spt_rs" };
    String[] Fix_EQP_ID = { "AFSPT100", "AFSPT200", "AFSPT300", "AFSPT400", "AFSPT500", "AFSPT600" };

    //給TextBox即時判斷傳給前端用
    ArrayList Label_UpValue = new ArrayList();
    ArrayList Label_LowValue = new ArrayList();

    String P3_Click_EQP_ID;
    int Select_Recipe_num = 0;

    String Refresh_Second;

    protected void Page_Load(object sender, EventArgs e)
    {
        //初始化Session，控制選擇EQP_ID
        if (Request.QueryString["P3_Click_EQP_ID"] == null)  //第3頁點的EQP_ID
        {
            ClearSession();  //先清空一次
            P3_Click_EQP_ID = Fix_EQP_ID[0];
        }
        else 
        {
            P3_Click_EQP_ID = Request.QueryString["P3_Click_EQP_ID"];
        }


        //初始化，調整秒數出現文字框用
        if (Session["P3_Change_Second"] == null)
        {
            Session["P3_Change_Second"] = "first";
        }

        //完成DB更新
        if (HttpContext.Current.Request.Cookies["UpdateDept"] != null && Session["P3_Final_Value"] != null && Session["P3_Done_Test"] != null && Session["P3_Done_Test"].ToString() == "1")
        {
            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));

            //開啟資料庫
            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
            MySqlConnection conn_act = new MySqlConnection(connection_act);
            conn_act.Open();

            //取得時間
            DateTime dt = DateTime.Now; // 取得現在時間
            String Now_Time = dt.ToString("yyyy-MM-dd HH:mm:ss"); // 轉成字串

            //MySql語句1
            string sqlQuery_act = "UPDATE `spt_depo_time` SET Recipe_Depo_Time = \"" + Session["P3_Final_Value"] + "\", Modified_Flag=\"true\" ,Update_User=\"" + user_name + "\",Update_Time = \"" + Now_Time + "\", SVM_Flag=\"wait\" " +
                                  " WHERE EQP_ID=\"" + P3_Click_EQP_ID + "\"";
            //執行
            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
            cmd_act.ExecuteNonQuery();


            //紀錄
            string[] Before_Value = Session["P3_Before_Value"].ToString().Split(','); //要顯示的資料
            string[] After_Value = Session["P3_Final_Value"].ToString().Split(','); //要顯示的資料
            string[] Recipe_Name_Order = Session["P3_Recipe_Name_Order"].ToString().Split(','); //要顯示的資料

            //讀取Default Value用
            DataTable DefaultValue_table = new DataTable();
            sqlQuery_act = "SELECT Recipe_Name,Default_Value FROM `spt_recipe_depo_time` WHERE EQP_ID='" + P3_Click_EQP_ID + "'";
            cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
            MySqlDataAdapter data_act = new MySqlDataAdapter();
            data_act.SelectCommand = cmd_act;
            data_act.Fill(DefaultValue_table);

            for (int i = 0; i < Before_Value.Length; i++)
            {
                if (Before_Value[i] != After_Value[i])  //前後值不一樣，新增進紀錄
                {
                    //先找到Default_Value
                    string DV = "";
                    for(int j = 0; j < DefaultValue_table.Rows.Count; j++)
                    {
                        if (DefaultValue_table.Rows[j][0].ToString() == Recipe_Name_Order[i])
                        {
                            DV = DefaultValue_table.Rows[j][1].ToString();
                        }
                    }

                    sqlQuery_act = "REPLACE INTO `spt_depo_time_log` (EQP_ID,Recipe_Name,Default_Value,Depo_Time_Before,Depo_Time_After,Target_Life,Update_User,Update_Time)" +
                                   "VALUES (\"" + P3_Click_EQP_ID + "\",\"" + Recipe_Name_Order[i] + "\",\"" + DV + "\",\"" + Before_Value[i] + "\",\"" + After_Value[i] + "\",\"" + Session["P3_Target_Life"].ToString() + "\",\"" + user_name + "\",\"" + Now_Time + "\")";
                    cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                    cmd_act.ExecuteNonQuery();
                }
            }
            conn_act.Close();

            //Response.Write(sqlQuery_act);

            //清空session
            ClearSession();

            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
            //HttpContext.Current.Response.Cookies["UpdateUserName"].Value = null;
            //HttpContext.Current.Response.Cookies["UpdateDept"].Value = null;
            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);

        }


        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        
        /*//MySql查詢語句1
        string sqlQuery = "SELECT Recipe_Name FROM `spt_recipe_depo_time` WHERE EQP_ID='" + P3_Click_EQP_ID + "'";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset column_table中
        data.Fill(column_table);
        */
        //------

        //MySql查詢語句：查資料
        string sqlQuery = "SELECT * FROM `spt_depo_time` WHERE EQP_ID='" + P3_Click_EQP_ID + "'";

        //讀取本頁秒數相關資料
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(data_table);

        //------

        //根據SVM_Flag判斷機台按鈕顏色 (讀全部機台)
        sqlQuery = "SELECT SVM_Flag FROM `spt_depo_time`";
        cmd = new MySqlCommand(sqlQuery, conn);
        data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(SVM_table);

        //根據對應EQP抓TGL區間
        sqlQuery = "SELECT Life_From,Life_To FROM `spt_target_life_range` WHERE EQP_ID=\"" + P3_Click_EQP_ID + "\"";
        cmd = new MySqlCommand(sqlQuery, conn);
        data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(TGL_Range_table);

        //根據對應EQP與TGL的DepoTime值
        sqlQuery = "SELECT Recipe_Name,Depo_Time_Value FROM `spt_recipe_depo_time` WHERE EQP_ID='" + P3_Click_EQP_ID + "'";
        cmd = new MySqlCommand(sqlQuery, conn);
        data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(DepoTime_table);

        //根據對應EQP與讀取Target Life與Mask Life值
        sqlQuery = "SELECT Target_Life,Mask_Life FROM `spt_target_life` WHERE EQP_ID='" + P3_Click_EQP_ID + "'";
        cmd = new MySqlCommand(sqlQuery, conn);
        data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(TGL_table);

        //抓Python更新時間值
        String CheckPythonName="";
        if (P3_Click_EQP_ID == Fix_EQP_ID[0])
            CheckPythonName ="Python120";
        else if (P3_Click_EQP_ID == Fix_EQP_ID[1])
            CheckPythonName = "Python320";
        else if (P3_Click_EQP_ID == Fix_EQP_ID[3])
            CheckPythonName = "Python420";
        else  //為了讓其他未平展的可以先顯示用
            CheckPythonName = "Python120";

        sqlQuery = "SELECT Update_Time FROM `spt_target_life` WHERE EQP_ID='" + CheckPythonName + "'";
        cmd = new MySqlCommand(sqlQuery, conn);
        data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(Python_table);

        conn.Close();  //關閉MYSQL資料庫連結


        Label Label_TGL = (Label)this.FindControl("Label_TGL");         //找到元件
        Label Label_MASK = (Label)this.FindControl("Label_MASK");
        Label Label_Python = (Label)this.FindControl("Label_Python");       
        int TGL_Value;

        Label_TGL.Text = "Target Life: " + TGL_table.Rows[0][0].ToString();
        //比較Python時間是否超過太久
        DateTime dt_last_time = Convert.ToDateTime(Python_table.Rows[0][0].ToString());
        DateTime dt_now = Convert.ToDateTime(DateTime.Now);
        TimeSpan span = dt_now.Subtract(dt_last_time); //算法是dtwo減去 dtone 
        if (span.Minutes > 0)
        {
            Label_Python.Text = CheckPythonName + "異常停止，請重新開啟Python或先手動調秒機台，最後更新時間: " + Python_table.Rows[0][0].ToString();
            Label_Python.ForeColor = ColorTranslator.FromHtml("#FF0000");
            Session["P3_Change_Second"] = "PythonDown";
        }
        else
        {
            Label_Python.Text = CheckPythonName + "更新時間: " + Python_table.Rows[0][0].ToString();
        }
        TGL_Value = int.Parse(TGL_table.Rows[0][0].ToString());

        if (P3_Click_EQP_ID == Fix_EQP_ID[4] || P3_Click_EQP_ID == Fix_EQP_ID[5])
            Label_MASK.Text = "Mask Life: " + TGL_table.Rows[0][1].ToString();
        else
            Label_MASK.Visible = false;

        Session["P3_Target_Life"] = TGL_Value.ToString();
        //---------完成TGL擷取與顯示----------

        //-----判斷TGL在哪個區間-----
        int TGL_Range_Index=-1;  //預設-1表示超過TGL區間範圍
        for (int i = 0; i < TGL_Range_table.Rows.Count; i++)
        { 
            int Test_low = int.Parse(TGL_Range_table.Rows[i][0].ToString());
            int Test_up = int.Parse(TGL_Range_table.Rows[i][1].ToString());
            if (Test_low <= TGL_Value & TGL_Value <= Test_up)
            {
                TGL_Range_Index = i;
                break;
            }
            /*
            else if (TGL_Value < Test_low | Test_up < TGL_Value)
            {
                TGL_Range_Index = -1;
            }
            */
        }
        //-----完成TGL在哪個區間，存在TGL_Range_Index-----



        //按鈕觸發狀態顏色顯示
        for (int i = 1; i < Fix_EQP_ID.Length + 1; i++)
        {
            Button Button_temp = (Button)FindControl("Button" + i.ToString());

            Button_temp.BorderColor = ColorTranslator.FromHtml("#8A8A8A");

            if (SVM_table.Rows[i - 1][0].ToString() != "false")  //紅色觸發
            {
                Button_temp.ForeColor = ColorTranslator.FromHtml("#800000");
                Button_temp.BackColor = ColorTranslator.FromHtml("#FF9966"); //設定背景顏色
            }
            else  //綠色沒觸發
            {
                Button_temp.ForeColor = ColorTranslator.FromHtml("#00800");
                Button_temp.BackColor = ColorTranslator.FromHtml("#CCFFCC"); //設定背景顏色
            }

        }


        //顯示表格
        Table Table1 = (Table)this.FindControl("Table1");         //找到元件

        //切秒數，處理要做紀錄的Session資料

        string[] column_table = data_table.Rows[0][6].ToString().Split(',');
        Select_Recipe_num = column_table.Length;
        Session["P3_Before_Value"] = data_table.Rows[0][1].ToString();
        string[] Value_split_before = Session["P3_Before_Value"].ToString().Split(','); //要顯示的資料


        if (Session["P3_Final_Value"] == null | data_table.Rows[0][2].ToString() == "spt" | Request.QueryString["P3_Click_EQP_ID"] == null)
        {
            string Final_Value = "";
            string Temp_Recipe_Order="";
            //string Explanation_Text = "";

            for (int num = 0; num < Select_Recipe_num; num++)
            {
                if (num == 0)
                {
                    Temp_Recipe_Order = column_table[num];//column_table.Rows[num][0].ToString();  //Recipe Name
                    Final_Value = (int.Parse(Value_split_before[num]) + 1).ToString();
                }
                else
                {
                    Temp_Recipe_Order = Temp_Recipe_Order + "," + column_table[num];//Temp_Recipe_Order + "," + column_table.Rows[num][0].ToString();  //Recipe Name
                    Final_Value = Final_Value + "," + (int.Parse(Value_split_before[num]) + 1).ToString();
                    //Explanation_Text = Explanation_Text + ",";
                }
            }

            Session["P3_Recipe_Name_Order"] = Temp_Recipe_Order;
            Session["P3_Final_Value"] = Final_Value;
            //Session["P3_Explanation_Text"] = Explanation_Text;

            if (data_table.Rows[0][2].ToString() == "spt")  //讀到後改回false
            {
                //開啟資料庫
                string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
                MySqlConnection conn_act = new MySqlConnection(connection_act);
                conn_act.Open();
                string sqlQuery_act = "UPDATE `spt_depo_time` SET Modified_Flag=\"false\"" + " WHERE EQP_ID=\"" + P3_Click_EQP_ID + "\"";
                MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
                cmd_act.ExecuteNonQuery();
                conn_act.Close();
                Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
            }

        }
        string[] Value_split_after = Session["P3_Final_Value"].ToString().Split(','); //要顯示的資料
        //string[] Explanation_split = Session["P3_Explanation_Text"].ToString().Split(','); //要顯示的資料

        //表格
        for (int i = 0; i < data_table.Columns.Count-1; i++)
        {

            if (i == 1)  //秒數
            {   /*
                for (int x = 0; x < Select_Recipe_num; x++)
                {
                    TableRow row_head = new TableRow();
                    TableCell cell_head = new TableCell();
                    cell_head.Text = column_table.Rows[x][0].ToString();
                    cell_head.Font.Size = 14;  //字型
                    cell_head.Font.Bold = true;  //字體粗體
                    cell_head.HorizontalAlign = HorizontalAlign.Left;
                    cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                    cell_head.BackColor = ColorTranslator.FromHtml("#FFEE99"); //設定背景顏色
                    row_head.Cells.Add(cell_head);

                    cell_head = new TableCell();
                    cell_head.Text = value_split[x];
                    cell_head.Font.Size = 12;  //字型
                    cell_head.Font.Bold = true;  //字體粗體
                    cell_head.HorizontalAlign = HorizontalAlign.Center;
                    row_head.Cells.Add(cell_head);
         
                    Table1.Rows.Add(row_head);
                }
                */
            }
            else
            {
                TableRow row_head = new TableRow();
                TableCell cell_head = new TableCell();
                cell_head.Text = data_table.Columns[i].ColumnName.ToString();
                cell_head.Font.Size = 14;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.ForeColor = ColorTranslator.FromHtml("#3333CC");
                cell_head.BackColor = ColorTranslator.FromHtml("#CCFFFF"); //設定背景顏色
                row_head.Cells.Add(cell_head);

                cell_head = new TableCell();
                cell_head.Text = data_table.Rows[0][i].ToString();
                cell_head.Font.Size = 12;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;

                //判斷Update_Time是否為今日已操作，若是則背景為粉色
                if (i == 2)
                {
                    if (data_table.Rows[0][i].ToString() == "true")
                    {
                        cell_head.Text = "等待寫入RCP";
                        cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                        cell_head.BackColor = ColorTranslator.FromHtml("#ffff00"); //設定背景顏色
                        Tune_Loading.Visible = true;  //調秒畫面
                        Refresh_Second = "10";
                    }
                    else
                    {
                        cell_head.Text = "自動更新RCP";
                        Refresh_Second = "60";
                    }
                }

                //判斷Update_Time是否為今日已操作，若是則背景為粉色
                if (i == 4)
                {
                    DateTime TempDate = DateTime.Parse(data_table.Rows[0][i].ToString());

                    if (TempDate.Year == DateTime.Now.Year && TempDate.Month == DateTime.Now.Month && TempDate.Day == DateTime.Now.Day)
                    {
                        cell_head.BackColor = ColorTranslator.FromHtml("#d8bfd8"); //設定背景顏色
                    }
                }

                row_head.Cells.Add(cell_head);

                //判斷SVM_Flag
                if (i == 5)
                {
                    if (data_table.Rows[0][i].ToString() == "true")
                    {
                        cell_head.ForeColor = ColorTranslator.FromHtml("#FF0000");
                        cell_head.BackColor = ColorTranslator.FromHtml("#ffb6c1"); //設定背景顏色
                    }
                    else if (data_table.Rows[0][i].ToString() == "wait")
                    {
                        cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                        cell_head.BackColor = ColorTranslator.FromHtml("#ffff00"); //設定背景顏色
                    }
                }

                Table1.Rows.Add(row_head);
            }
        }


        //下面調秒資訊表格
        //顯示表格
        Table Table2 = (Table)this.FindControl("Table2");         //找到元件


        //表格標頭
        for (int i = -1; i < Select_Recipe_num; i++)
        {
            if (i == -1)
            {
                TableRow row_head = new TableRow();
                TableCell cell_head = new TableCell();
                cell_head.Text = "Recipe_Name";
                cell_head.Font.Size = 12;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                cell_head.BackColor = ColorTranslator.FromHtml("#FFEE99"); //設定背景顏色
                row_head.Cells.Add(cell_head);

                cell_head = new TableCell();
                if (data_table.Rows[0][5].ToString() == "true")
                {
                    cell_head.Text = "調前秒數";
                }
                else
                {
                    cell_head.Text = "現在秒數";
                }
                cell_head.Font.Size = 12;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                cell_head.BackColor = ColorTranslator.FromHtml("#FFEE99"); //設定背景顏色
                row_head.Cells.Add(cell_head);

                if (data_table.Rows[0][5].ToString() != "false")
                {
                    cell_head = new TableCell();
                    cell_head.Text = "調後秒數";
                    cell_head.Font.Size = 12;  //字型
                    cell_head.Font.Bold = true;  //字體粗體
                    cell_head.HorizontalAlign = HorizontalAlign.Center;
                    cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                    cell_head.BackColor = ColorTranslator.FromHtml("#FFEE99"); //設定背景顏色
                    row_head.Cells.Add(cell_head);
                }

                cell_head = new TableCell();
                cell_head.Text = "Target Life <br />" + "對應預設秒數";
                cell_head.Font.Size = 12;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                cell_head.BackColor = ColorTranslator.FromHtml("#FFEE99"); //設定背景顏色
                row_head.Cells.Add(cell_head);

                cell_head = new TableCell();
                cell_head.Text = "其他";
                cell_head.Font.Size = 12;  //字型
                cell_head.Font.Bold = true;  //字體粗體
                cell_head.HorizontalAlign = HorizontalAlign.Center;
                cell_head.ForeColor = ColorTranslator.FromHtml("#643200");
                cell_head.BackColor = ColorTranslator.FromHtml("#FFEE99"); //設定背景顏色
                row_head.Cells.Add(cell_head);

                Table2.Rows.Add(row_head);
            }
            else
            {
                TableRow row_head = new TableRow();
                TableCell cell_data = new TableCell();
                cell_data.Text = column_table[i]; //column_table.Rows[i][0].ToString();  //Recipe Name
                cell_data.Font.Size = 12;  //字型
                cell_data.Font.Bold = true;  //字體粗體
                //cell_data.HorizontalAlign = HorizontalAlign.Center;
                cell_data.ForeColor = ColorTranslator.FromHtml("#643200");
                cell_data.BackColor = ColorTranslator.FromHtml("#FFFFFF"); //設定背景顏色
                row_head.Cells.Add(cell_data);

                cell_data = new TableCell();
                cell_data.Text = Value_split_before[i];
                cell_data.Font.Size = 12;  //字型
                cell_data.Font.Bold = true;  //字體粗體
                cell_data.HorizontalAlign = HorizontalAlign.Center;
                cell_data.ForeColor = ColorTranslator.FromHtml("#008000");
                cell_data.BackColor = ColorTranslator.FromHtml("#FFFFFF"); //設定背景顏色
                cell_data.Width = new Unit(100, UnitType.Pixel);
                row_head.Cells.Add(cell_data);


                if (data_table.Rows[0][5].ToString() != "false")  //SVM_Flag
                {
                    if (Session["P3_Change_Second"].ToString() == "first" || Session["P3_Change_Second"].ToString() == "false" || Session["P3_Change_Second"].ToString() == "PythonDown")
                    {
                        cell_data = new TableCell();
                        cell_data.Text = Value_split_after[i];  //之後要改從設定根據TGL讀值
                        cell_data.Font.Size = 13;  //字型
                        cell_data.Font.Bold = true;  //字體粗體
                        cell_data.HorizontalAlign = HorizontalAlign.Center;
                        cell_data.ForeColor = ColorTranslator.FromHtml("#800000");
                        cell_data.BackColor = ColorTranslator.FromHtml("#FFFFFF"); //設定背景顏色
                        cell_data.Width = new Unit(100, UnitType.Pixel);
                        row_head.Cells.Add(cell_data);
                    }
                    else  //可修改
                    {
                        cell_data = new TableCell();
                        cell_data.HorizontalAlign = HorizontalAlign.Center;
                        cell_data.BackColor = ColorTranslator.FromHtml("#FFFFFF"); //設定背景顏色
                        cell_data.Width = new Unit(100, UnitType.Pixel);
                        TextBox textbox = new TextBox();
                        textbox.ID = "TextBox_" + Convert.ToString(i);
                        textbox.Text = Value_split_after[i];
                        textbox.Font.Size = 12;  //字型
                        textbox.Font.Bold = true;  //字體粗體
                        textbox.ForeColor = ColorTranslator.FromHtml("#800000");
                        textbox.Width = new Unit("90%");
                        textbox.Height = new Unit("90%");
                        textbox.Style["text-align"] = "center";
                        textbox.Style["align"] = "center";
                        //textbox.TextChanged += TextChanged;  //文字更改事件
                        //textbox.AutoPostBack = true;
                        textbox.Attributes.Add("oninput", "javascript:Text_Check()");
                        cell_data.Controls.Add(textbox);
                        row_head.Cells.Add(cell_data);
                    }
                }

                //Target Life對應預測秒數
                cell_data = new TableCell();

                if (TGL_Range_Index == -1)
                {
                    cell_data.Text = "無對應秒數";
                }
                else
                {
                    for (int x = 0; x < DepoTime_table.Rows.Count; x++)
                    {
                        if (column_table[i] == DepoTime_table.Rows[x][0].ToString()) //符合Recipe Name，進入切割對應秒數
                        {
                            string[] Value_split_Default = DepoTime_table.Rows[x][1].ToString().Split(',');
                            cell_data.Text = Value_split_Default[TGL_Range_Index];

                            //傳值給前端用
                            Label_LowValue.Add((int.Parse(Value_split_Default[0]) - 3).ToString());
                            Label_UpValue.Add((int.Parse(Value_split_Default[Value_split_Default.Length-1]) + 2).ToString());

                            break;
                        }
                    }
                }

                cell_data.Font.Size = 12;  //字型
                cell_data.Font.Bold = true;  //字體粗體
                cell_data.HorizontalAlign = HorizontalAlign.Center;
                cell_data.ForeColor = ColorTranslator.FromHtml("#696969");
                cell_data.BackColor = ColorTranslator.FromHtml("#FFFFFF"); //設定背景顏色
                cell_data.Width = new Unit(100, UnitType.Pixel);
                row_head.Cells.Add(cell_data);



                cell_data = new TableCell();
                cell_data.HorizontalAlign = HorizontalAlign.Center;
                cell_data.BackColor = ColorTranslator.FromHtml("#FFFFFF"); //設定背景顏色
                cell_data.Width = new Unit(150, UnitType.Pixel);
                Label Label = new Label();
                Label.ID = "Label_" + Convert.ToString(i);
                //Label.Text = "YA";
                Label.ForeColor = ColorTranslator.FromHtml("#a0522d");
                Label.Font.Size = 12;  //字型
                Label.Font.Bold = true;  //字體粗體
                cell_data.Controls.Add(Label);
                row_head.Cells.Add(cell_data);

                /*cell_data = new TableCell();
                cell_data.Text = Explanation_split[i];
                cell_data.Font.Size = 12;  //字型
                cell_data.Font.Bold = true;  //字體粗體
                cell_data.HorizontalAlign = HorizontalAlign.Center;
                cell_data.ForeColor = ColorTranslator.FromHtml("#a0522d");
                cell_data.BackColor = ColorTranslator.FromHtml("#FFFFFF"); //設定背景顏色
                cell_data.Width = new Unit(150, UnitType.Pixel);
                row_head.Cells.Add(cell_data);
                */

                Table2.Rows.Add(row_head);
            }
        }

        //隱藏或關閉按鈕功能
        if (data_table.Rows[0][5].ToString() == "false" || Session["P3_Change_Second"].ToString() == "PythonDown")
        {
            Button Button_Second = (Button)FindControl("Button_Second");
            Button Button_Reset = (Button)FindControl("Button_Reset");
            Button Button_Adjust = (Button)FindControl("Button_Adjust");

            Button_Second.Visible = false;
            Button_Reset.Visible = false;
            Button_Adjust.Enabled = false;
            Button_Adjust.ForeColor = ColorTranslator.FromHtml("#696969");
            Button_Adjust.BackColor = ColorTranslator.FromHtml("#c0c0c0");
        }

        //編輯秒數時，鎖死確定調整鈕
        if (Session["P3_Change_Second"].ToString() == "true" || Session["P3_Change_Second"].ToString() == "first")
        {
            Button Button_Adjust = (Button)FindControl("Button_Adjust");
            Button_Adjust.Enabled = false;
            Button_Adjust.ForeColor = ColorTranslator.FromHtml("#696969");
            Button_Adjust.BackColor = ColorTranslator.FromHtml("#c0c0c0");
        }


        //每60秒更新
        if (Session["P3_Change_Second"].ToString() == "first" || Session["P3_Change_Second"].ToString() == "false")
        {
            Response.AppendHeader("Refresh", Refresh_Second);
        }

        //傳值給前端，即時判斷文字框輸入的值是否符合範圍與數值
        String[] Pass_Label_UpValue = (String[])Label_UpValue.ToArray(typeof(string));
        String[] Pass_Label_LowValue = (String[])Label_LowValue.ToArray(typeof(string));

        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x1", string.Format("<script>var Get_Label_UpValue =\"{0}\";</script>", string.Join(",", Pass_Label_UpValue)));
        this.Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "x2", string.Format("<script>var Get_Label_LowValue =\"{0}\";</script>", string.Join(",", Pass_Label_LowValue)));


    }

    /* //只有傳到伺服端才會觸發
    private void TextChanged(object sender, EventArgs e)
    {
        //將修改的值存回Session["P3_Final_Value"]，讓Label顯示同步
        string Final_Value = "";
        string Explanation_Text = "";

        for (int num = 0; num < Select_Recipe_num; num++)
        {
            string TextBox_ID = "TextBox_" + num.ToString();
            TextBox TextBox_Adjust = (TextBox)FindControl(TextBox_ID);


            string Label_ID = "Label_" + num.ToString();
            Label Label_Adjust = (Label)FindControl(Label_ID);

            if (num == 0)
            {
                Final_Value = TextBox_Adjust.Text;
                Explanation_Text = Label_Adjust.Text;
            }
            else
            {
                Final_Value = Final_Value + "," + TextBox_Adjust.Text;
                Explanation_Text = Explanation_Text + "," + "N";
            }
        }
        Session["P3_Final_Value"] = Final_Value;
        Session["P3_Explanation_Text"] = Explanation_Text;

        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }
    */

    //確定調整
    protected void Button_Adjust_event(object sender, EventArgs e)
    {
        /*
        string Final_Value = "";
        string Before_Value = "";

        for (int num = 0; num < Select_Recipe_num; num++)
        {
            string TextBox_ID = "TextBox_" + num.ToString();
            TextBox TextBox_Adjust = (TextBox)FindControl(TextBox_ID);

            if (num == 0)
            {
                Final_Value = TextBox_Adjust.Text;
            }
            else
            {
                Final_Value = Final_Value + "," + TextBox_Adjust.Text;
            }
        }


        Session["P3_Before_Value"] = Before_Value;
        Session["P3_Final_Value"] = Final_Value;
        */

        Session["P3_Done_Test"] = 1;

        //UAC認證
        Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_TuneDepoTime&P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }

    //修改秒數按鈕
    protected void Button_Second_event(object sender, EventArgs e)
    {
        if (Session["P3_Change_Second"].ToString() == "first" || Session["P3_Change_Second"].ToString() == "false")
        {
            Session["P3_Change_Second"] = "true";
        }
        else
        {
            Session["P3_Change_Second"] = "false";

            //將修改的值存回Session["P3_Final_Value"]，讓Label顯示同步
            string Final_Value = "";
            //string Explanation_Text = "";

            for (int num = 0; num < Select_Recipe_num; num++)
            {
                string TextBox_ID = "TextBox_" + num.ToString();
                TextBox TextBox_Adjust = (TextBox)FindControl(TextBox_ID);

                if (num == 0)
                {
                    Final_Value = TextBox_Adjust.Text;
                    //Explanation_Text = "說明說明";
                }
                else
                {
                    Final_Value = Final_Value + "," + TextBox_Adjust.Text;
                    //Explanation_Text = Explanation_Text + "," + "YA";
                }
            }

            Session["P3_Final_Value"] = Final_Value;
            //Session["P3_Explanation_Text"] = Explanation_Text;
        }
        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }

    private void ClearSession()
    {
        Session["P3_Before_Value"] = null;
        Session["P3_Final_Value"] = null;
        Session["P3_Recipe_Name_Order"] = null;
        Session["P3_Done_Test"] = null;
        Session["P3_Change_Second"] = "first";
    }

    protected void Button_1_event(object sender, EventArgs e)
    {
        P3_Click_EQP_ID = Fix_EQP_ID[0];
        ClearSession();
        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }

    protected void Button_2_event(object sender, EventArgs e)
    {
        P3_Click_EQP_ID = Fix_EQP_ID[1];
        ClearSession();
        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }

    protected void Button_3_event(object sender, EventArgs e)
    {
        P3_Click_EQP_ID = Fix_EQP_ID[2];
        ClearSession();
        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }

    protected void Button_4_event(object sender, EventArgs e)
    {
        P3_Click_EQP_ID = Fix_EQP_ID[3];
        ClearSession();
        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }

    protected void Button_5_event(object sender, EventArgs e)
    {
        P3_Click_EQP_ID = Fix_EQP_ID[4];
        ClearSession();
        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }

    protected void Button_6_event(object sender, EventArgs e)
    {
        P3_Click_EQP_ID = Fix_EQP_ID[5];
        ClearSession();
        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }

    protected void Button_Reset_event(object sender, EventArgs e)
    {
        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        //---讀取Default Value用，改成 Default + 1---
        /*
        DataTable Reset_table = new DataTable();
        string sqlQuery = "SELECT Recipe_Name,Depo_Time_Value FROM `spt_recipe_depo_time` WHERE EQP_ID='" + P3_Click_EQP_ID + "'";
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(Reset_table);
        conn.Close();

        string Final_Value = "";
        string[] Recipe_Name_Order = Session["P3_Recipe_Name_Order"].ToString().Split(','); //要顯示的資料

        for (int x = 0; x < Recipe_Name_Order.Length; x++)
        {
            for (int y = 0; y < Recipe_Name_Order.Length; y++)
            {
                if (Recipe_Name_Order[x] == Reset_table.Rows[y][0].ToString())
                {
                    if (x == 0)
                    {
                        string[] Temp_Time = Reset_table.Rows[y][1].ToString().Split(',');
                        Final_Value = Temp_Time[0];
                    }
                    else
                    {
                        string[] Temp_Time = Reset_table.Rows[y][1].ToString().Split(',');
                        Final_Value = Final_Value + "," + Temp_Time[0];
                    }

                    break;
                }

            }
        }
        */

        //---讀取Default Value用，改成 Default + 1---
        DataTable Reset_table = new DataTable();
        string sqlQuery = "SELECT Recipe_Name,Default_Value FROM `spt_recipe_depo_time` WHERE EQP_ID='" + P3_Click_EQP_ID + "'";
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;
        data.Fill(Reset_table);
        conn.Close();

        string Final_Value = "";
        string[] Recipe_Name_Order = Session["P3_Recipe_Name_Order"].ToString().Split(','); //要顯示的資料

        for (int x = 0; x < Recipe_Name_Order.Length; x++)
        {
            for (int y = 0; y < Recipe_Name_Order.Length; y++)
            {
                if (Recipe_Name_Order[x] == Reset_table.Rows[y][0].ToString())
                {
                    if (x == 0)
                    {
                        Final_Value = Reset_table.Rows[y][1].ToString();
                    }
                    else
                    {
                        Final_Value = Final_Value + "," + Reset_table.Rows[y][1].ToString();
                    }

                    break;
                }

            }
        }
        

         
        Session["P3_Change_Second"] = "false";
        Session["P3_Final_Value"] = Final_Value;
        Response.Redirect("R2R_TuneDepoTime.aspx?P3_Click_EQP_ID=" + P3_Click_EQP_ID);
    }
}

