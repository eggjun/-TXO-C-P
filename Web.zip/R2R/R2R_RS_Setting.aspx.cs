﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Drawing;
using System.Text;


public partial class R2R_RS_Setting : Page
{
    DataTable data_table = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Request.Cookies["UpdateDept"] != null && Session["SelectProduct"] != null && Session["SelectPEP"] != null && Session["Done_Test"].ToString() == "1")
        {
            String user_name = HttpUtility.UrlDecode(HttpContext.Current.Request.Cookies["UpdateUserName"].Value, Encoding.GetEncoding("big5"));

            //開啟資料庫
            string connection_act = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
            MySqlConnection conn_act = new MySqlConnection(connection_act);
            conn_act.Open();

            //取得時間
            DateTime dt = DateTime.Now; // 取得現在時間
            String Now_Time = dt.ToString("yyyy-MM-dd HH:mm:ss"); // 轉成字串

            //判斷每一個值是否為空值
            string Temp_sql = "";

            if (Session["T1"].ToString() != "")
                Temp_sql = "USL=\"" + Session["T1"] + "\",";
            else
                Temp_sql = "USL=null,";

            if (Session["T2"].ToString() != "")
                Temp_sql = Temp_sql + "UCL=\"" + Session["T2"] + "\",";
            else
                Temp_sql = Temp_sql + "UCL=null,";

            if (Session["T3"].ToString() != "")
                Temp_sql = Temp_sql + "CL=\"" + Session["T3"] + "\",";
            else
                Temp_sql = Temp_sql + "CL=null,";

            if (Session["T4"].ToString() != "")
                Temp_sql = Temp_sql + "LCL=\"" + Session["T4"] + "\",";
            else
                Temp_sql = Temp_sql + "LCL=null,";

            if (Session["T5"].ToString() != "")
                Temp_sql = Temp_sql + "LSL=\"" + Session["T5"] + "\",";
            else
                Temp_sql = Temp_sql + "LSL=null,";


            //MySql語句
            string sqlQuery_act = "UPDATE `spt_rs_spec` SET " + Temp_sql + "Update_User=\"" + user_name + "\",Update_Time = \"" + Now_Time +
                                  "\" WHERE Product=\"" + Session["SelectProduct"] + "\" AND PEP=\"" + Session["SelectPEP"] + "\"";

            //執行
            MySqlCommand cmd_act = new MySqlCommand(sqlQuery_act, conn_act);
            cmd_act.ExecuteNonQuery();
            conn_act.Close();

            //Response.Write(sqlQuery_act);

            //清空session
            ClearSession();

            HttpContext.Current.Response.Cookies["UpdateUserName"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
            HttpContext.Current.Response.Cookies["UpdateDept"].Path = "/L8A/func/YouHsin_8A_RS_R2R";
            //HttpContext.Current.Response.Cookies["UpdateUserName"].Value = null;
            //HttpContext.Current.Response.Cookies["UpdateDept"].Value = null;
            HttpContext.Current.Response.Cookies["UpdateUserName"].Expires = DateTime.Now.AddDays(-1);
            HttpContext.Current.Response.Cookies["UpdateDept"].Expires = DateTime.Now.AddDays(-1);
        }





        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        //MySql查詢語句
        string sqlQuery = "SELECT * FROM `spt_rs_spec`";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset data_table中
        data.Fill(data_table);

        conn.Close();



        //顯示表格
        Table Table1 = (Table)this.FindControl("Table1");         //找到元件
        Table1.BorderStyle = BorderStyle.Solid;
        Table1.BorderWidth = 2;

        Table Table2 = (Table)this.FindControl("Table2");         //找到元件
  


        //表格標頭
        TableRow row_head = new TableRow();
        for (int i = 0; i < data_table.Columns.Count; i++)
        {
            TableCell cell_head = new TableCell();

            if (i == 10)
                cell_head.Width = new Unit("15%");
            else
                cell_head.Width = new Unit("8%");

            cell_head.Text = data_table.Columns[i].ColumnName.ToString();
            cell_head.Font.Bold = true;  //字體粗體
            cell_head.ForeColor = Color.White;
            cell_head.BackColor = ColorTranslator.FromHtml("#D2B48C"); //設定背景顏色
            row_head.Cells.Add(cell_head);
        }

        //欄位修改
        TableCell cell_temp = new TableCell();
        cell_temp.Width = new Unit("5%");
        cell_temp.Text = "調整";
        cell_temp.Font.Bold = true;  //字體粗體
        cell_temp.ForeColor = Color.White;
        cell_temp.BackColor = ColorTranslator.FromHtml("#D2B48C"); //設定背景顏色
        row_head.Cells.Add(cell_temp);

        Table1.Rows.Add(row_head);

        //Data
        for (int row_index = 0; row_index < data_table.Rows.Count; row_index++)
        {
            TableRow row = new TableRow();
            for (int column_index = 0; column_index < data_table.Columns.Count; column_index++)
            {
                TableCell cell1 = new TableCell();

                //修改部分，要將文字改成Textbox
                if (Session["Done_Test"] != null && Session["Done_Test"].ToString() == "0" && int.Parse(Session["select_index"].ToString()) == row_index && (column_index >= 4 & column_index <= 8))
                {
                    TextBox textbox = new TextBox();
                    textbox.ID = "TextBox_Adjust_" + Convert.ToString(column_index);
                    textbox.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                    textbox.Width = new Unit("80%");
                    textbox.Style["text-align"] = "center";
                    cell1.Controls.Add(textbox);
                }
                else
                {
                    cell1.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                    cell1.Font.Bold = true;  //字體粗體
                }

                if (column_index == 10)
                    cell1.Width = new Unit("15%");
                else
                    cell1.Width = new Unit("8%");

                row.Cells.Add(cell1);
            }


            //調區間按鈕
            TableCell btnCell = new TableCell();

            Button btn = new Button();

            //先判斷有沒有null，使用&&
            if (Session["Done_Test"] != null && Session["Done_Test"].ToString() == "0" && int.Parse(Session["select_index"].ToString()) == row_index)
            {
                btn.Text = "更新";
            }
            else
            {
                btn.Text = "修改";
            }


            btn.ID = "Button_Adjust_" + Convert.ToString(row_index);
            btn.Click += new EventHandler(Button_Adjust);
            btnCell.Controls.Add(btn);
            btnCell.Width = new Unit("5%");
            row.Cells.Add(btnCell);

            Table2.Rows.Add(row);
        }
    }

    //修改按鈕
    protected void Button_Adjust(object sender, EventArgs e)
    {

        string Button_ID = ((Button)sender).ID;
        int select_index = int.Parse(Button_ID.ToString().Split('_')[2]);

        Button button_now = (Button)FindControl(Button_ID);
        TextBox TextBox_Adjust_1 = (TextBox)FindControl("TextBox_Adjust_4");
        TextBox TextBox_Adjust_2 = (TextBox)FindControl("TextBox_Adjust_5");
        TextBox TextBox_Adjust_3 = (TextBox)FindControl("TextBox_Adjust_6");
        TextBox TextBox_Adjust_4 = (TextBox)FindControl("TextBox_Adjust_7");
        TextBox TextBox_Adjust_5 = (TextBox)FindControl("TextBox_Adjust_8");

        Session["select_index"] = select_index;
        Session["Done_Test"] = 0;

        if (button_now.Text == "更新")
        {
            Session["T1"] = TextBox_Adjust_1.Text;
            Session["T2"] = TextBox_Adjust_2.Text;
            Session["T3"] = TextBox_Adjust_3.Text;
            Session["T4"] = TextBox_Adjust_4.Text;
            Session["T5"] = TextBox_Adjust_5.Text;
            Session["SelectProduct"] = data_table.Rows[select_index][0].ToString();
            Session["SelectPEP"] = data_table.Rows[select_index][1].ToString();
            Session["Done_Test"] = 1;

            //UAC認證
            Response.Redirect("http://cimuac:7102/UAC/?UL=http://tw100040269/L8A/func/YouHsin_8A_RS_R2R/UAC_Check_P11.asp?from=R2R_RS_Setting");
        }

        Response.Redirect("R2R_RS_Setting.aspx");

    }

    private void ClearSession()
    {
        Session["T1"] = null;
        Session["T2"] = null;
        Session["T3"] = null;
        Session["T4"] = null;
        Session["T5"] = null;
        Session["SelectProduct"] = null;
        Session["SelectPEP"] = null;
        Session["Done_Test"] = null;
    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
       
    }

}

