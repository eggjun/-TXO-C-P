﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Collections;
using System.Drawing;



public partial class SPC_Setting : Page
{
    DataTable data_table = new DataTable();

    protected void Page_Load(object sender, EventArgs e)
    {
        //---查詢資料庫---
        string connection = ConfigurationManager.ConnectionStrings["test1ConnectionString"].ConnectionString;
        MySqlConnection conn = new MySqlConnection(connection);
        conn.Open();

        //MySql查詢語句
        string sqlQuery = "SELECT * FROM `spt_spc_spec`";

        //執行查詢
        MySqlCommand cmd = new MySqlCommand(sqlQuery, conn);
        MySqlDataAdapter data = new MySqlDataAdapter();
        data.SelectCommand = cmd;

        //將查詢結果注入到dataset data_table中
        data.Fill(data_table);

        conn.Close();

        //Response.Write(data_table.Columns[0].ColumnName);
        //Response.Write(data_table.Rows[0][1].ToString());


        //顯示表格
        Table Table1 = (Table)this.FindControl("Table1");         //找到元件
        Table1.BorderStyle = BorderStyle.Solid;
        Table1.BorderWidth = 2;

        Table Table2 = (Table)this.FindControl("Table2");         //找到元件




        //表格標頭
        TableRow row_head = new TableRow();
        for (int i = 0; i < data_table.Columns.Count; i++)
        {
            TableCell cell_head = new TableCell();
            cell_head.Width = 130;
            cell_head.Text = data_table.Columns[i].ColumnName.ToString();
            cell_head.Font.Bold = true;  //字體粗體
            cell_head.Font.Size = FontUnit.XLarge;  //大字型
            cell_head.ForeColor = Color.White;
            cell_head.BackColor = ColorTranslator.FromHtml("#D2B48C"); //設定背景顏色
            row_head.Cells.Add(cell_head);
        }

        Table1.Rows.Add(row_head);

        //Data
        for (int row_index = 0; row_index < data_table.Rows.Count; row_index++)
        {
            TableRow row = new TableRow();
            for (int column_index = 0; column_index < data_table.Columns.Count; column_index++)
            {
                TableCell cell1 = new TableCell();
                cell1.Width = 100;
                cell1.Text = data_table.Rows[row_index][column_index].ToString();  //要顯示的資料
                cell1.Font.Bold = true;  //字體粗體
                row.Cells.Add(cell1);
            }

            Table2.Rows.Add(row);
        }
    }


    protected void Page_LoadComplete(object sender, EventArgs e)
    {

    }

}

